# OT12 All-Cell Summary Manifest

This file describes the files copied into `summary/`.

## Code Snapshot

The files under `code_snapshot/` are copied from `OT12_all_exper/` so the final workflow can be inspected without searching the full project tree.

### Top Level

- `code_snapshot/README.original.md`: original project README, copied for context.
- `code_snapshot/run_submit_pipeline.sbatch`: early all-cell wrapper. It submits OT1, OT1 UMAP, prepare, and the older hard-count OT2 submit wrapper.
- `code_snapshot/submit_pipeline.sh`: helper called by `run_submit_pipeline.sbatch`.

Note: the final reported OT2 result uses molecule-neighborhood OT2, submitted by `ot2/run_submit_ot2_hardcount_molneigh_from_existing.sbatch`.

### OT1

- `code_snapshot/ot1/ot1_fgw_pcaexpr_allcells_lowrank20_eps0_a0p9.py`: first-round all-cell OT1 implementation.
  - Uses PCA-space expression cost: log-normalized expression -> scale(max_value=10) -> PCA(50).
  - Uses FGW alpha=0.9, epsilon=0, low-rank rank=20.
  - Uses type-balanced marginal and unbalanced blend.
  - Uses low-rank coupling factors `q/r/g` instead of dense transport matrix materialization.
- `code_snapshot/ot1/run_ot1_allcells_lowrank20_eps0_a0p9.sbatch`: Slurm wrapper for the first-round OT1 script.

### OT2: Final Molecule-Neighborhood Hard-Count Path

- `code_snapshot/ot2/run_submit_ot2_hardcount_molneigh_from_existing.sbatch`: main first-round OT2 submit wrapper for the final mol-neigh result.
- `code_snapshot/ot2/run_prepare_ot2_hardcount_molneigh_from_existing.sbatch`: prepares/links existing window, transcript, and cell tables for the mol-neigh OT2 run.
- `code_snapshot/ot2/submit_ot2_hardcount_molneigh_windows.sh`: computes the number of windows and submits the Slurm array for mol-neigh OT2.
- `code_snapshot/ot2/run_ot2_hardcount_molneigh_windows.sbatch`: Slurm array task wrapper. Each task runs one window chunk.
- `code_snapshot/ot2/ot2_window_hardcount_molneigh_worker.py`: core mol-neigh OT2 worker.
  - Restricts candidate cells to cells within `hard_cut_um=12` for each molecule/gene.
  - Runs Sinkhorn OT with epsilon=0.05 and threshold=1e-3.
  - Writes per-window molecule assignments and convergence summaries.
- `code_snapshot/ot2/run_merge_ot2_hardcount_molneigh_allcells.sbatch`: merges mol-neigh OT2 window outputs, creates hard-count and lognorm h5ad, and summarizes convergence.
- `code_snapshot/ot2/merge_window_hardcount_assignments.py`: merge implementation.
  - Reads `worker_out/window_*/assignments.parquet`.
  - Resolves overlapping windows by keeping the highest-confidence assignment per molecule.
  - Builds cell-by-gene integer counts.
- `code_snapshot/ot2/make_lognorm_from_counts.py`: converts hard-count h5ad to log-normalized h5ad with `normalize_total(target_sum=1e4) + log1p`.
- `code_snapshot/ot2/summarize_ot2_convergence.py`: summarizes Sinkhorn convergence across all window/gene problems.
- `code_snapshot/ot2/run_repair_ot2_hardcount_molneigh_missing_then_merge.sbatch`: repair helper for missing OT2 windows caused by Slurm array failures.

### OT2: Earlier Non-Molecule-Neighborhood Hard-Count Path

These files are included because the early all-cell submit wrapper references them. They are not the final reported path.

- `code_snapshot/ot2/run_prepare_ot2_hardcount_allcells.sbatch`
- `code_snapshot/ot2/submit_ot2_hardcount_windows.sh`
- `code_snapshot/ot2/run_ot2_hardcount_windows.sbatch`
- `code_snapshot/ot2/ot2_window_hardcount_worker.py`
- `code_snapshot/ot2/run_merge_ot2_hardcount_allcells.sbatch`
- `code_snapshot/ot2/run_submit_ot2_hardcount_and_downstream.sbatch`

### Evaluation

- `code_snapshot/eval/run_umap_compare_original_vs_target.py`: shared UMAP comparison script.
- `code_snapshot/eval/run_umap_ot1_allcells.sbatch`: first-round OT1 UMAP wrapper.
- `code_snapshot/eval/run_umap_ot2_hardcount_molneigh_allcells.sbatch`: first-round mol-neigh OT2 UMAP wrapper.
- `code_snapshot/eval/run_umap_ot2_hardcount_allcells.sbatch`: earlier non-mol-neigh OT2 UMAP wrapper.

### Iteration Round 2

- `code_snapshot/iter_round2/README.original.md`: original iteration-round-2 README.
- `code_snapshot/iter_round2/run_submit_iter_round2_pipeline.sbatch`: submits full second-round OT1 -> OT2 -> UMAP -> summary chain.
- `code_snapshot/iter_round2/ot1/ot1_fgw_pcaexpr_iter2_from_ot2.py`: second-round OT1 implementation.
  - Reads first-round OT2 log-normalized hard-count h5ad as spatial input.
  - Uses `existing_lognorm`, with no extra gene-sum mass matching in the default sbatch.
  - Keeps alpha=0.9, epsilon=0, rank=20, PCA(50) expression cost.
- `code_snapshot/iter_round2/ot1/run_ot1_iter2_from_ot2_molneigh.sbatch`: Slurm wrapper for second-round OT1.
- `code_snapshot/iter_round2/ot2/run_prepare_iter2_ot2_inputs.sbatch`: prepares/links OT2 input tables for round 2.
- `code_snapshot/iter_round2/ot2/run_ot2_iter2_windows.sbatch`: second-round OT2 window-array wrapper.
- `code_snapshot/iter_round2/ot2/run_merge_iter2_ot2.sbatch`: second-round OT2 merge, lognorm conversion, and convergence summary wrapper.
- `code_snapshot/iter_round2/eval/run_umap_ot1_iter2.sbatch`: second-round OT1 UMAP wrapper.
- `code_snapshot/iter_round2/eval/run_umap_ot2_iter2.sbatch`: second-round OT2 UMAP wrapper.
- `code_snapshot/iter_round2/eval/collect_iter_round2_summary.py`: collects iteration-round-2 metrics and summaries.
- `code_snapshot/iter_round2/eval/run_collect_iter_round2_summary.sbatch`: Slurm wrapper for the collector.

## Result Summaries

- `result_summaries/iter1_ot1_run_summary.json`: first-round OT1 run summary.
- `result_summaries/iter1_ot2_merge_summary.json`: first-round mol-neigh OT2 merge summary.
- `result_summaries/iter1_ot2_lognorm_summary.json`: first-round OT2 lognorm conversion summary.
- `result_summaries/iter1_ot2_umap_metrics.csv`: first-round OT2 UMAP metrics.
- `result_summaries/iter2_ot1_run_summary.json`: second-round OT1 run summary.
- `result_summaries/iter2_ot2_merge_summary.json`: second-round OT2 merge summary.
- `result_summaries/iter2_ot2_convergence_summary.json`: second-round OT2 Sinkhorn convergence summary.
- `result_summaries/iter_round2_umap_metric_summary_long.csv`: combined UMAP/expression-space metrics for iter1 and iter2.
- `result_summaries/iter_round2_ot2_assignment_summary.csv`: iter1 vs iter2 OT2 molecule assignment summary.
- `result_summaries/iter_round2_run_summary.json`: combined JSON summary for iteration-round-2 comparison.

## Not Included

Small-patch experiments are intentionally not copied into this summary, per request.

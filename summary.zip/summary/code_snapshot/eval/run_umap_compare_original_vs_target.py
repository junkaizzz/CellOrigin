#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
from matplotlib.patches import Patch
from scipy import sparse
from sklearn.metrics import silhouette_score


XLSX_10X = (
    "/scratch/beul/jzhang79/projects/xenium_baysor/data/sample2/"
    "Cell_Barcode_Type_Matrices.xlsx"
)
XENIUM_SHEET = "Xenium Fig 6 (unsupervised)"

RANDOM_STATE = 0
N_PCS = 30
N_NEIGHBORS = 15
MIN_DIST = 0.35
MIN_CLASS_SIZE = 20
SILHOUETTE_SAMPLE_SIZE = 5000
INVALID_LABELS = {"Unknown", "Not Plotted", "NA", "nan", "group"}

PALETTE = [
    "#E41A1C", "#377EB8", "#4DAF4A", "#984EA3", "#FF7F00",
    "#FFD92F", "#A65628", "#F781BF", "#00A9A5", "#000000",
    "#7FC97F", "#BEAED4", "#FDC086", "#386CB0", "#F0027F",
    "#BF5B17", "#666666", "#1B9E77", "#D95F02", "#7570B3",
    "#E7298A", "#66A61E", "#E6AB02", "#A6761D", "#17BECF",
    "#BCBD22", "#8C564B", "#9467BD", "#2CA02C", "#D62728",
]
SPECIAL_COLORS = {"Unknown": "#bdbdbd", "Not Plotted": "#e0e0e0"}
DOMAIN_COLORS = {"Original spatial": "#4C78A8", "Target": "#F58518"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compare original spatial h5ad against one target h5ad by UMAP and silhouette score."
    )
    parser.add_argument("--original_h5ad", required=True)
    parser.add_argument("--target_h5ad", required=True)
    parser.add_argument("--target_label", required=True)
    parser.add_argument("--out_dir", required=True)
    parser.add_argument("--prefix", required=True)
    return parser.parse_args()


def load_celltype_map() -> dict[str, str]:
    dfx = pd.read_excel(XLSX_10X, sheet_name=XENIUM_SHEET)
    need_cols = {"Barcode", "Cluster"}
    missing_cols = need_cols - set(dfx.columns)
    if missing_cols:
        raise KeyError(
            f"Sheet {XENIUM_SHEET!r} missing columns: {missing_cols}. "
            f"Found columns: {list(dfx.columns)}"
        )
    dfx = dfx[["Barcode", "Cluster"]].dropna().copy()
    dfx["Barcode"] = dfx["Barcode"].astype(str)
    dfx["Cluster"] = dfx["Cluster"].astype(str)
    return dict(zip(dfx["Barcode"].values, dfx["Cluster"].values))


CELLTYPE_MAP = load_celltype_map()


def attach_celltype(adata: sc.AnnData, key: str = "celltype_10x") -> sc.AnnData:
    ids = adata.obs_names.astype(str)
    labels = pd.Series(ids).map(CELLTYPE_MAP).fillna("Unknown").astype(str).values
    adata.obs[key] = pd.Categorical(labels)
    matched = int(np.sum(labels != "Unknown"))
    print(f"[attach_celltype] matched {matched}/{len(labels)} = {matched / len(labels):.3f}")
    return adata


def build_color_map(categories):
    cats = list(categories)
    ordered = []
    for name in ["Unknown", "Not Plotted"]:
        if name in cats:
            ordered.append(name)
    for cat in cats:
        if cat not in ordered:
            ordered.append(cat)
    non_special = [cat for cat in ordered if cat not in SPECIAL_COLORS]
    if len(non_special) > len(PALETTE):
        raise ValueError(f"Need {len(non_special)} non-special colors, but palette has {len(PALETTE)}.")
    cmap = {}
    pal_i = 0
    for cat in ordered:
        if cat in SPECIAL_COLORS:
            cmap[cat] = SPECIAL_COLORS[cat]
        else:
            cmap[cat] = PALETTE[pal_i]
            pal_i += 1
    return cmap, ordered


def dense_float32(X):
    if sparse.issparse(X):
        return X.toarray().astype(np.float32)
    return np.asarray(X, dtype=np.float32)


def prepare_asis_lognorm_scaled(adata: sc.AnnData) -> sc.AnnData:
    out = adata.copy()
    out.X = dense_float32(out.X)
    out.layers["asis_lognorm"] = out.X.copy()
    sc.pp.scale(out, max_value=10)
    return out


def run_umap(adata: sc.AnnData) -> sc.AnnData:
    n_comps = min(N_PCS, max(1, min(adata.n_obs, adata.n_vars) - 1))
    sc.pp.pca(adata, n_comps=n_comps, random_state=RANDOM_STATE)
    n_pcs_use = min(N_PCS, adata.obsm["X_pca"].shape[1])
    sc.pp.neighbors(
        adata,
        n_neighbors=min(N_NEIGHBORS, max(1, adata.n_obs - 1)),
        n_pcs=n_pcs_use,
        random_state=RANDOM_STATE,
    )
    sc.tl.umap(adata, min_dist=MIN_DIST, random_state=RANDOM_STATE)
    return adata


def valid_label_mask(labels):
    labels = np.asarray(labels).astype(str)
    mask = ~np.isin(labels, list(INVALID_LABELS))
    counts = pd.Series(labels[mask]).value_counts()
    keep = set(counts[counts >= MIN_CLASS_SIZE].index)
    return mask & np.isin(labels, list(keep))


def score_representation(X, labels):
    labels = np.asarray(labels).astype(str)
    keep = valid_label_mask(labels)
    if keep.sum() < 3 or len(np.unique(labels[keep])) < 2:
        return np.nan, int(len(np.unique(labels[keep]))), int(keep.sum())
    sample_size = min(SILHOUETTE_SAMPLE_SIZE, int(keep.sum()))
    if sample_size >= int(keep.sum()):
        sample_size = None
    return (
        float(
            silhouette_score(
                X[keep],
                labels[keep],
                metric="euclidean",
                sample_size=sample_size,
                random_state=RANDOM_STATE,
            )
        ),
        int(len(np.unique(labels[keep]))),
        int(keep.sum()),
    )


def collect_metrics(name, adata):
    labels = adata.obs["celltype_10x"].astype(str).to_numpy()
    rows = []
    reps = [
        ("umap", np.asarray(adata.obsm["X_umap"], dtype=float)),
        ("pca", np.asarray(adata.obsm["X_pca"], dtype=float)),
        ("asis_lognorm", dense_float32(adata.layers["asis_lognorm"])),
        ("scaled_lognorm", dense_float32(adata.X)),
    ]
    for rep_name, X in reps:
        score, n_classes, n_cells = score_representation(X, labels)
        rows.append(
            {
                "dataset": name,
                "representation": rep_name,
                "metric": "euclidean",
                "silhouette_score": score,
                "n_classes": n_classes,
                "n_cells": n_cells,
            }
        )
    return rows


def plot_umap(adata, title, out_png, fixed_cmap, fixed_order, key="celltype_10x", s=2, ax=None):
    emb = adata.obsm["X_umap"]
    colors = adata.obs[key].astype(str).map(fixed_cmap).values
    if ax is None:
        fig, ax = plt.subplots(figsize=(8, 6))
    else:
        fig = ax.figure
    ax.scatter(emb[:, 0], emb[:, 1], s=s, c=colors, linewidths=0)
    ax.set_title(title)
    ax.set_xlabel("UMAP1")
    ax.set_ylabel("UMAP2")
    handles = [Patch(facecolor=fixed_cmap[c], edgecolor="none", label=c) for c in fixed_order if c in fixed_cmap]
    ax.legend(handles=handles, title=key, loc="center left", bbox_to_anchor=(1.02, 0.5), frameon=False)
    if out_png is not None:
        fig.tight_layout()
        fig.savefig(out_png, dpi=300, bbox_inches="tight")
        print("Saved:", out_png)


def plot_domain_umap(adata, out_png):
    emb = adata.obsm["X_umap"]
    colors = adata.obs["domain"].astype(str).map(DOMAIN_COLORS).values
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(emb[:, 0], emb[:, 1], s=1.5, c=colors, linewidths=0, alpha=0.75)
    ax.set_title("Joint UMAP colored by domain")
    ax.set_xlabel("UMAP1")
    ax.set_ylabel("UMAP2")
    handles = [Patch(facecolor=DOMAIN_COLORS[name], edgecolor="none", label=name) for name in DOMAIN_COLORS]
    ax.legend(handles=handles, loc="center left", bbox_to_anchor=(1.02, 0.5), frameon=False)
    fig.tight_layout()
    fig.savefig(out_png, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print("Saved:", out_png)


def main() -> None:
    args = parse_args()
    out_dir = os.path.abspath(args.out_dir)
    os.makedirs(out_dir, exist_ok=True)

    original = sc.read_h5ad(args.original_h5ad)
    target = sc.read_h5ad(args.target_h5ad)
    original.obs_names = original.obs_names.astype(str)
    target.obs_names = target.obs_names.astype(str)
    attach_celltype(original)
    attach_celltype(target)

    all_cats = pd.Categorical(
        pd.concat([original.obs["celltype_10x"].astype(str), target.obs["celltype_10x"].astype(str)], axis=0)
    ).categories
    fixed_cmap, fixed_order = build_color_map(all_cats)
    pd.DataFrame([{"celltype": c, "color": fixed_cmap[c]} for c in fixed_order]).to_csv(
        os.path.join(out_dir, f"{args.prefix}_celltype_colors.csv"),
        index=False,
    )

    original_scaled = prepare_asis_lognorm_scaled(original)
    target_scaled = prepare_asis_lognorm_scaled(target)
    run_umap(original_scaled)
    run_umap(target_scaled)

    metrics = []
    metrics.extend(collect_metrics("Original spatial separate", original_scaled))
    metrics.extend(collect_metrics(f"{args.target_label} separate", target_scaled))

    fig, ax = plt.subplots(figsize=(8, 6))
    plot_umap(
        original_scaled,
        "Original spatial ASIS_LOGNORM_SCALED",
        os.path.join(out_dir, f"{args.prefix}_original_spatial_separate.png"),
        fixed_cmap,
        fixed_order,
        ax=ax,
    )
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 6))
    plot_umap(
        target_scaled,
        f"{args.target_label} ASIS_LOGNORM_SCALED",
        os.path.join(out_dir, f"{args.prefix}_target_separate.png"),
        fixed_cmap,
        fixed_order,
        ax=ax,
    )
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    plot_umap(original_scaled, "Original spatial", None, fixed_cmap, fixed_order, ax=axes[0])
    plot_umap(target_scaled, args.target_label, None, fixed_cmap, fixed_order, ax=axes[1])
    fig.tight_layout()
    compare_png = os.path.join(out_dir, f"{args.prefix}_compare_original_vs_target_separate.png")
    fig.savefig(compare_png, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print("Saved:", compare_png)

    original_joint = original.copy()
    target_joint = target.copy()
    original_joint.obs["domain"] = "Original spatial"
    target_joint.obs["domain"] = "Target"
    joint = sc.concat([original_joint, target_joint], join="inner", label=None, index_unique="-")
    joint.obs["domain"] = pd.Categorical(joint.obs["domain"], list(DOMAIN_COLORS))
    joint.obs["celltype_10x"] = pd.Categorical(joint.obs["celltype_10x"].astype(str))
    joint = prepare_asis_lognorm_scaled(joint)
    run_umap(joint)
    metrics.extend(collect_metrics("Joint space all cells", joint))

    joint_original = joint[joint.obs["domain"].astype(str).to_numpy() == "Original spatial"].copy()
    joint_target = joint[joint.obs["domain"].astype(str).to_numpy() == "Target"].copy()
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), sharex=True, sharey=True)
    plot_umap(joint_original, "Original spatial in joint UMAP space", None, fixed_cmap, fixed_order, ax=axes[0], s=2)
    plot_umap(joint_target, f"{args.target_label} in joint UMAP space", None, fixed_cmap, fixed_order, ax=axes[1], s=2)
    fig.tight_layout()
    joint_split_png = os.path.join(out_dir, f"{args.prefix}_joint_space_by_xenium_fig6.png")
    fig.savefig(joint_split_png, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print("Saved:", joint_split_png)
    plot_domain_umap(joint, os.path.join(out_dir, f"{args.prefix}_joint_space_domain.png"))

    metrics_df = pd.DataFrame(metrics)
    metrics_path = os.path.join(out_dir, f"{args.prefix}_metrics.csv")
    metrics_df.to_csv(metrics_path, index=False)
    print(metrics_df.to_string(index=False))
    print("Saved:", metrics_path)


if __name__ == "__main__":
    main()

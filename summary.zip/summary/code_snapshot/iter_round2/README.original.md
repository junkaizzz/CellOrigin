# OT12 All-Cell Iteration Round 2

Goal: repeat one OT1 -> OT2 iteration using the already validated all-cell OT1/OT2 pipeline.

Round 1 fixed inputs:

- OT1 iter1:
  `/scratch/beul/jzhang79/projects/Moscot/code/OT12_all_exper/results/ot1/allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/spatial_patch_soft_barycentric_fgw_labelstruct_unweighted_typebalancedmarginal_unbalancedblend.h5ad`
- OT2 iter1:
  `/scratch/beul/jzhang79/projects/Moscot/code/OT12_all_exper/results/ot2/hardcount_molneigh_allcells_from_allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/ot2_allcells_hardcount_molneigh_lognorm_cell_by_gene.h5ad`

Round 2 logic:

1. Run OT1 again using OT2 iter1 lognorm h5ad as the spatial expression input.
2. The OT2 iter1 source is still a hard-count result. The file used by OT1 is the paired log-normalized h5ad:
   - hard-count counts: `ot2_allcells_hardcount_molneigh_cell_by_gene.h5ad`
   - OT1 input: `ot2_allcells_hardcount_molneigh_lognorm_cell_by_gene.h5ad`
   - the lognorm file is made from hard counts by `normalize_total(target_sum=1e4) + log1p`.
3. No extra gene-sum mass matching is applied in the default round-2 pipeline. The OT1 copied script still supports `mass_match_reference_gene_sums` for comparison with the old `code/OT12` iteration style, but the default sbatch uses `--spatial-input-mode existing_lognorm`.
4. Use the same OT1 settings as the validated all-cell run:
   - PCA expression cost: normalize/log already present for input, then scale(max_value=10) + PCA(50) for FGW cost.
   - alpha=0.9
   - epsilon=0
   - lowrank rank=20
   - tau_a=0.8, tau_b=0.9
   - type-balanced marginal
   - unbalanced blend
5. Run OT2 again using the same all-cell molecule-neighborhood hard-count OT2:
   - window_size=250um
   - step=125um
   - hard_cut_um=12
   - epsilon=0.05
   - max_iters=2000
6. Save UMAP plots, metrics, OT2 molecule assignment summary, and Sinkhorn convergence summary.

Submit:

```bash
cd /scratch/beul/jzhang79/projects/Moscot/code
sbatch OT12_all_exper/iter_round2/run_submit_iter_round2_pipeline.sbatch 80
```

The argument `80` is the max concurrent OT2 window-array jobs.

Job IDs:

```text
OT12_all_exper/iter_round2/results/job_ids_iter_round2_latest.txt
```

Main outputs:

```text
OT12_all_exper/iter_round2/results/ot1/iter2_from_ot2_molneigh_allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/
OT12_all_exper/iter_round2/results/ot2/hardcount_molneigh_allcells_from_iter2_from_ot2_molneigh_allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/
OT12_all_exper/iter_round2/results/eval/
```

Key files:

- OT1 iter2 h5ad:
  `results/ot1/iter2_from_ot2_molneigh_allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/spatial_patch_soft_barycentric_fgw_labelstruct_unweighted_typebalancedmarginal_unbalancedblend.h5ad`
- OT1 iter2 summary:
  `results/ot1/iter2_from_ot2_molneigh_allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/run_summary_fgw54_debug.json`
- OT2 iter2 lognorm h5ad:
  `results/ot2/hardcount_molneigh_allcells_from_iter2_from_ot2_molneigh_allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/ot2_iter2_hardcount_molneigh_lognorm_cell_by_gene.h5ad`
- OT2 iter2 merge summary:
  `results/ot2/hardcount_molneigh_allcells_from_iter2_from_ot2_molneigh_allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/ot2_iter2_hardcount_molneigh_merge_summary.json`
- OT2 iter2 convergence summary:
  `results/ot2/hardcount_molneigh_allcells_from_iter2_from_ot2_molneigh_allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/ot2_iter2_sinkhorn_convergence_summary.json`
- UMAP and score summaries:
  `results/eval/umap_original_vs_ot1_iter2/`
  `results/eval/umap_original_vs_ot2_iter2/`
  `results/eval/iter_round2_umap_metric_summary_long.csv`
  `results/eval/iter_round2_ot2_assignment_summary.csv`
  `results/eval/iter_round2_run_summary.json`

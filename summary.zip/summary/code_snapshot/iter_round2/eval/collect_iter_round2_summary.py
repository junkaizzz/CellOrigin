#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Collect iter1/iter2 OT1/OT2 metrics and OT2 convergence summaries."""

import json
from pathlib import Path

import pandas as pd


PIPE_DIR = Path("/scratch/beul/jzhang79/projects/Moscot/code/OT12_all_exper")
ITER_DIR = PIPE_DIR / "iter_round2"
RUN_TAG = "iter2_from_ot2_molneigh_allcells_pcaexpr_lowrank20_a0p9_eps0_pca50"


def read_csv_if_exists(path: Path, label: str) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame([{"source": label, "missing": str(path)}])
    df = pd.read_csv(path)
    df.insert(0, "source", label)
    return df


def read_json_if_exists(path: Path) -> dict:
    return json.loads(path.read_text()) if path.exists() else {"missing": str(path)}


def main() -> None:
    out_dir = ITER_DIR / "results" / "eval"
    out_dir.mkdir(parents=True, exist_ok=True)

    metric_paths = [
        (
            PIPE_DIR / "results/ot1/allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/umap_original_vs_ot1/ot1_allcells_lowrank20_a0p9_eps0_metrics.csv",
            "iter1_ot1",
        ),
        (
            PIPE_DIR / "results/ot2/hardcount_molneigh_allcells_from_allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/umap_original_vs_ot2/ot2_allcells_hardcount_molneigh_metrics.csv",
            "iter1_ot2_molneigh",
        ),
        (
            ITER_DIR / "results/eval/umap_original_vs_ot1_iter2/ot1_iter2_from_ot2_molneigh_metrics.csv",
            "iter2_ot1_from_ot2",
        ),
        (
            ITER_DIR / "results/eval/umap_original_vs_ot2_iter2/ot2_iter2_hardcount_molneigh_metrics.csv",
            "iter2_ot2_molneigh",
        ),
    ]
    metrics = pd.concat([read_csv_if_exists(p, label) for p, label in metric_paths], ignore_index=True)
    metrics.to_csv(out_dir / "iter_round2_umap_metric_summary_long.csv", index=False)

    iter1_ot2_run = PIPE_DIR / "results/ot2/hardcount_molneigh_allcells_from_allcells_pcaexpr_lowrank20_a0p9_eps0_pca50"
    iter2_ot2_run = ITER_DIR / "results/ot2" / f"hardcount_molneigh_allcells_from_{RUN_TAG}"
    iter2_ot1_run = ITER_DIR / "results/ot1" / RUN_TAG

    payload = {
        "iter1_ot1_run_summary": read_json_if_exists(
            PIPE_DIR / "results/ot1/allcells_pcaexpr_lowrank20_a0p9_eps0_pca50/run_summary_fgw54_debug.json"
        ),
        "iter1_ot2_merge_summary": read_json_if_exists(
            iter1_ot2_run / "ot2_allcells_hardcount_molneigh_merge_summary.json"
        ),
        "iter2_ot1_run_summary": read_json_if_exists(iter2_ot1_run / "run_summary_fgw54_debug.json"),
        "iter2_ot2_merge_summary": read_json_if_exists(
            iter2_ot2_run / "ot2_iter2_hardcount_molneigh_merge_summary.json"
        ),
        "iter2_ot2_convergence_summary": read_json_if_exists(
            iter2_ot2_run / "ot2_iter2_sinkhorn_convergence_summary.json"
        ),
    }
    (out_dir / "iter_round2_run_summary.json").write_text(json.dumps(payload, indent=2))

    rows = []
    for label, key in [
        ("iter1_ot2_molneigh", "iter1_ot2_merge_summary"),
        ("iter2_ot2_molneigh", "iter2_ot2_merge_summary"),
    ]:
        s = payload[key]
        total = None
        if label == "iter1_ot2_molneigh":
            prep = read_json_if_exists(iter1_ot2_run / "preprocess_config.json")
            total = prep.get("n_transcripts")
        else:
            prep = read_json_if_exists(iter2_ot2_run / "preprocess_config.json")
            total = prep.get("n_transcripts")
        final = s.get("unique_molecules_final")
        rows.append({
            "stage": label,
            "n_transcripts": total,
            "unique_molecules_final": final,
            "molecule_loss_rate": (1.0 - final / total) if total and final else None,
            "unique_cells_used": s.get("unique_cells_used"),
            "unique_genes_used": s.get("unique_genes_used"),
        })
    pd.DataFrame(rows).to_csv(out_dir / "iter_round2_ot2_assignment_summary.csv", index=False)

    print("Saved:", out_dir / "iter_round2_umap_metric_summary_long.csv")
    print("Saved:", out_dir / "iter_round2_run_summary.json")
    print("Saved:", out_dir / "iter_round2_ot2_assignment_summary.csv")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import json
import argparse
import numpy as np
import pandas as pd
import scanpy as sc

from moscot.problems.generic import FGWProblem

# =========================================================
# 0) Paths
# =========================================================
XENIUM_DIR = "/scratch/beul/jzhang79/projects/xenium_baysor/data/sample2"
SCP_EXPR_DIR = "/scratch/beul/jzhang79/projects/xenium_baysor/data/breast/SCP1039/expression"
SCP_META_CSV = "/scratch/beul/jzhang79/projects/xenium_baysor/data/breast/SCP1039/metadata/Whole_miniatlas_meta.csv"

XLSX_10X = "/scratch/beul/jzhang79/projects/xenium_baysor/data/sample2/Cell_Barcode_Type_Matrices.xlsx"
XENIUM_SHEET = "Xenium Fig 6 (unsupervised)"
CELLS_PARQUET = f"{XENIUM_DIR}/cells.parquet"

PIPE_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))


def value_tag(name: str, value: float | int | str) -> str:
    text = f"{value:g}" if isinstance(value, float) else str(value)
    return f"{name}{text}".replace("-", "m").replace(".", "p")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Robustness test: use scale + PCA expression embedding as the FGW expression cost."
    )
    parser.add_argument("--alpha", type=float, default=0.9)
    parser.add_argument("--rank", type=int, default=20)
    parser.add_argument(
        "--epsilon",
        type=float,
        default=0.0,
        help="Normalized FGW epsilon. With --epsilon-alpha-correction, solver epsilon is epsilon / alpha.",
    )
    parser.add_argument(
        "--epsilon-alpha-multiplier",
        type=float,
        default=1.0,
        help="Use epsilon_to_solver = epsilon * multiplier / alpha.",
    )
    parser.add_argument("--tau-a", type=float, default=0.8)
    parser.add_argument("--tau-b", type=float, default=0.9)
    parser.add_argument("--n-spatial", type=int, default=1000000000)
    parser.add_argument("--n-scrna", type=int, default=1000000000)
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument("--scale-cost", type=str, default="mean")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--out-tag", type=str, default=None)
    parser.add_argument(
        "--expr-pca-n-comps",
        type=int,
        default=50,
        help="Number of PCA components used for the FGW expression cost.",
    )
    parser.add_argument(
        "--expr-scale-max-value",
        type=float,
        default=10.0,
        help="Clip scaled expression values before PCA, matching the common Scanpy scale(max_value=10) workflow.",
    )
    parser.add_argument(
        "--cost-sample-size",
        type=int,
        default=1000,
        help="Cells per domain used for pre-solve cost diagnostics.",
    )
    parser.add_argument(
        "--spatial-input-h5ad",
        default="",
        help="Optional spatial h5ad to use instead of raw Xenium counts. Used for OT1 iteration from OT2.",
    )
    parser.add_argument(
        "--spatial-input-mode",
        default="raw_counts",
        choices=["raw_counts", "existing_lognorm", "mass_match_reference_gene_sums"],
        help=(
            "How to interpret --spatial-input-h5ad. raw_counts runs normalize/log1p; "
            "existing_lognorm uses .X as already log-normalized; "
            "mass_match_reference_gene_sums rescales columns to match --spatial-reference-h5ad."
        ),
    )
    parser.add_argument(
        "--spatial-reference-h5ad",
        default="",
        help="Reference h5ad used by mass_match_reference_gene_sums.",
    )
    return parser.parse_args()


ARGS = parse_args()
RUN_TAG = ARGS.out_tag or "_".join(
    [
        value_tag("a", ARGS.alpha),
        value_tag("rank", ARGS.rank),
        value_tag("eps", ARGS.epsilon),
        value_tag("c", ARGS.epsilon_alpha_multiplier),
        value_tag("pca", ARGS.expr_pca_n_comps),
        value_tag("tauA", ARGS.tau_a),
        value_tag("tauB", ARGS.tau_b),
        value_tag("n", ARGS.n_spatial),
    ]
)

OUT_DIR = os.path.join(PIPE_DIR, "results", "ot1", RUN_TAG)
os.makedirs(OUT_DIR, exist_ok=True)

# =========================================================
# 1) Knobs
# =========================================================
RNG_SEED = ARGS.seed

# IMPORTANT:
# rank = -1 uses the full-rank solver; rank >= 0 uses the low-rank solver.
N_SPATIAL = ARGS.n_spatial
N_SCRNA = ARGS.n_scrna
PATCH_MODE = "center_square"   # center_square | center_circle | random
PATCH_RADIUS_UM = 1200.0        # only used if PATCH_MODE == center_circle

# expression term and structure term
LINEAR_COST = "sq_euclidean"
STRUCT_COST = "sq_euclidean"

# paper-style/default-like FGW hyperparameters
ALPHA = ARGS.alpha
EPSILON_NORMALIZED = ARGS.epsilon
EPSILON_ALPHA_MULTIPLIER = ARGS.epsilon_alpha_multiplier
EPSILON_ALPHA_CORRECTION = True
EPSILON = EPSILON_NORMALIZED * EPSILON_ALPHA_MULTIPLIER / ALPHA
TAU_A = ARGS.tau_a
TAU_B = ARGS.tau_b
BATCH_SIZE = ARGS.batch_size
SCALE_COST = ARGS.scale_cost
EXPR_PCA_N_COMPS = ARGS.expr_pca_n_comps
EXPR_SCALE_MAX_VALUE = ARGS.expr_scale_max_value

RANK = ARGS.rank


SCRNA_CELLTYPE_COL = "celltype_minor"
SPATIAL_CELLTYPE_COL = "spatial_celltype_10x"

# outputs
OUT_SP_ORIG = f"{OUT_DIR}/spatial_patch_original_for_umap.h5ad"
OUT_SP_SOFT_FGW = f"{OUT_DIR}/spatial_patch_soft_barycentric_fgw_labelstruct_unweighted_typebalancedmarginal_unbalancedblend.h5ad"
OUT_GROUP_TYPE_MASS = f"{OUT_DIR}/spatialgroup_to_scrna_type_mass_debug.csv"
OUT_COUPLING_NPZ = f"{OUT_DIR}/ot1_fgw54_debug_coupling_spatial_to_scrna_typebalancedmarginal.npz"
OUT_RUN_SUMMARY = f"{OUT_DIR}/run_summary_fgw54_debug.json"


# =========================================================
# 2) Helpers
# =========================================================
def preprocess(a: sc.AnnData) -> sc.AnnData:
    a = a.copy()
    sc.pp.normalize_total(a, target_sum=1e4)
    sc.pp.log1p(a)
    a.X = a.X.toarray().astype(np.float32) if hasattr(a.X, "toarray") else np.asarray(a.X, dtype=np.float32)
    return a


def dense_float32(X) -> np.ndarray:
    return X.toarray().astype(np.float32) if hasattr(X, "toarray") else np.asarray(X, dtype=np.float32)


def use_existing_lognorm(a: sc.AnnData) -> sc.AnnData:
    a = a.copy()
    a.X = dense_float32(a.X)
    return a


def mass_match_reference_gene_sums(a: sc.AnnData, reference_h5ad: str) -> sc.AnnData:
    if not reference_h5ad:
        raise ValueError("--spatial-reference-h5ad is required for mass_match_reference_gene_sums")

    ref = sc.read_h5ad(reference_h5ad)
    ref.obs_names = ref.obs_names.astype(str)
    ref.var_names = ref.var_names.astype(str)

    common_genes = a.var_names.intersection(ref.var_names)
    if len(common_genes) == 0:
        raise RuntimeError("No common genes between spatial input and reference h5ad.")

    a = a[:, common_genes].copy()
    ref = ref[:, common_genes].copy()
    X = dense_float32(a.X)
    X_ref = dense_float32(ref.X)

    src_col = X.sum(axis=0).astype(np.float64)
    ref_col = X_ref.sum(axis=0).astype(np.float64)
    scale = np.divide(ref_col, src_col, out=np.zeros_like(ref_col), where=src_col > 0)
    X_scaled = X * scale[None, :].astype(np.float32)

    out = a.copy()
    out.X = X_scaled.astype(np.float32)
    out.uns["ot12_all_iter_spatial_input_mode"] = "mass_match_reference_gene_sums"
    out.uns["ot12_all_iter_spatial_reference_h5ad"] = reference_h5ad
    out.uns["ot12_all_iter_gene_scale_min_median_max"] = [
        float(np.min(scale)) if scale.size else 0.0,
        float(np.median(scale)) if scale.size else 0.0,
        float(np.max(scale)) if scale.size else 0.0,
    ]
    return out


def normalize_barcode(x: str) -> str:
    x = str(x).upper()
    hits = re.findall(r"[ACGT]+", x)
    if not hits:
        return ""
    return max(hits, key=len)


def attach_scrna_metadata(sc_ref: sc.AnnData, meta_csv: str, celltype_col: str) -> sc.AnnData:
    meta = pd.read_csv(meta_csv, low_memory=False)

    if celltype_col not in meta.columns:
        raise ValueError(f"{celltype_col} not found in metadata columns: {list(meta.columns)}")
    if "NAME" not in meta.columns:
        raise ValueError(f"'NAME' column not found in metadata columns: {list(meta.columns)}")

    meta = meta.copy()
    meta = meta[meta["NAME"].astype(str) != "TYPE"].copy()

    meta["barcode_clean"] = meta["NAME"].astype(str).map(normalize_barcode)
    meta = meta[meta["barcode_clean"] != ""].copy()
    meta.index = meta["barcode_clean"]
    meta = meta[~meta.index.duplicated(keep="first")]

    sc_ref = sc_ref.copy()
    sc_ref.obs["barcode_clean"] = pd.Index(sc_ref.obs_names.astype(str)).map(normalize_barcode)

    matched = sc_ref.obs["barcode_clean"].isin(meta.index)
    n_matched = int(matched.sum())

    print("[scRNA metadata]")
    print("scRNA cells:", sc_ref.n_obs)
    print("metadata rows:", meta.shape[0])
    print("matched barcodes:", n_matched)

    if n_matched == 0:
        raise ValueError("No barcodes matched between sc_ref.obs_names and metadata after normalization.")

    if n_matched < sc_ref.n_obs:
        print(f"Warning: only {n_matched}/{sc_ref.n_obs} scRNA cells matched metadata.")
        sc_ref = sc_ref[matched.to_numpy()].copy()

    sc_clean = sc_ref.obs["barcode_clean"].astype(str).tolist()
    sc_ref.obs[celltype_col] = meta.loc[sc_clean, celltype_col].astype(str).values

    if sc_ref.obs[celltype_col].isna().any():
        raise ValueError(f"Found missing values in {celltype_col} after metadata join.")

    return sc_ref


def attach_spatial_labels(sp: sc.AnnData, xlsx_path: str, sheet_name: str, key: str) -> sc.AnnData:
    dfx = pd.read_excel(xlsx_path, sheet_name=sheet_name)

    need_cols = {"Barcode", "Cluster"}
    missing_cols = need_cols - set(dfx.columns)
    if missing_cols:
        raise KeyError(
            f"Sheet '{sheet_name}' missing columns: {missing_cols}. "
            f"Found columns: {list(dfx.columns)}"
        )

    dfx = dfx[["Barcode", "Cluster"]].copy()
    dfx["Barcode"] = dfx["Barcode"].astype(str)
    dfx["Cluster"] = dfx["Cluster"].astype(str)
    dfx = dfx.dropna(subset=["Barcode", "Cluster"])

    celltype_map = dict(zip(dfx["Barcode"].values, dfx["Cluster"].values))

    sp = sp.copy()
    ids = sp.obs_names.astype(str)
    labels = pd.Series(ids).map(celltype_map).fillna("Unknown").astype(str).values
    sp.obs[key] = pd.Categorical(labels)

    matched = int(np.sum(labels != "Unknown"))
    print("[spatial labels]")
    print(f"matched {matched}/{len(labels)} = {matched/len(labels):.3f}")
    print(pd.Series(labels).value_counts().head(10))

    return sp


def make_binary_structural_embedding(labels: np.ndarray, all_types: list[str]) -> np.ndarray:
    type_to_idx = {t: i for i, t in enumerate(all_types)}
    Z = np.zeros((len(labels), len(all_types)), dtype=np.float32)
    idx = np.array([type_to_idx[str(x)] for x in labels], dtype=np.int64)
    Z[np.arange(len(labels)), idx] = 1.0 / np.sqrt(2.0)
    return Z


def make_type_balanced_marginal(labels: np.ndarray) -> tuple[np.ndarray, dict[str, int], dict[str, float]]:
    """Give each observed label the same total marginal mass, split uniformly within the label."""
    labels = np.asarray(labels).astype(str)
    counts = pd.Series(labels).value_counts().sort_index()
    n_types = float(len(counts))
    type_total_mass = {str(t): 1.0 / n_types for t in counts.index}
    type_counts = {str(t): int(n) for t, n in counts.items()}

    marginals = np.array(
        [type_total_mass[str(x)] / float(type_counts[str(x)]) for x in labels],
        dtype=np.float64,
    )
    marginals = marginals / marginals.sum()
    return marginals, type_counts, type_total_mass


def unbalanced_scrna_blend_fraction(row_mass: np.ndarray, source_marginal: np.ndarray) -> np.ndarray:
    """Convert unbalanced row mass to the fraction replaced by scRNA expression."""
    source_marginal = np.asarray(source_marginal, dtype=np.float32)
    if np.any(source_marginal <= 0):
        raise ValueError("Source marginal must be positive for row-mass blend.")
    frac = row_mass.astype(np.float32) / source_marginal
    frac = np.clip(frac, 0.0, 1.0).astype(np.float32)
    return frac


def finite_array_stats(x: np.ndarray, prefix: str) -> dict[str, float | int | bool]:
    arr = np.asarray(x)
    finite = np.isfinite(arr)
    out: dict[str, float | int | bool] = {
        f"{prefix}_size": int(arr.size),
        f"{prefix}_finite_count": int(finite.sum()),
        f"{prefix}_nan_count": int(np.isnan(arr).sum()),
        f"{prefix}_posinf_count": int(np.isposinf(arr).sum()),
        f"{prefix}_neginf_count": int(np.isneginf(arr).sum()),
        f"{prefix}_all_finite": bool(finite.all()),
    }
    if finite.any():
        vals = arr[finite].astype(np.float64, copy=False)
        qs = np.percentile(vals, [0, 1, 5, 25, 50, 75, 95, 99, 100])
        names = ["min", "p01", "p05", "p25", "median", "p75", "p95", "p99", "max"]
        out.update({f"{prefix}_{name}": float(val) for name, val in zip(names, qs)})
        out[f"{prefix}_mean"] = float(vals.mean())
    return out


def build_pca_expression_embedding(
    adata: sc.AnnData,
    n_spatial: int,
    n_comps: int,
    scale_max_value: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, dict[str, float | int | bool | str]]:
    """Build the FGW expression cost in scaled PCA space, not UMAP space."""
    pca_adata = adata.copy()
    pca_adata.X = (
        pca_adata.X.toarray().astype(np.float32)
        if hasattr(pca_adata.X, "toarray")
        else np.asarray(pca_adata.X, dtype=np.float32)
    )

    before_scale_stats = finite_array_stats(pca_adata.X, "expr_lognorm_before_scale")
    sc.pp.scale(pca_adata, max_value=scale_max_value)
    after_scale_stats = finite_array_stats(pca_adata.X, "expr_scaled_before_pca")

    max_n_comps = max(1, min(pca_adata.n_obs - 1, pca_adata.n_vars - 1))
    actual_n_comps = int(min(n_comps, max_n_comps))
    sc.pp.pca(pca_adata, n_comps=actual_n_comps, random_state=seed)

    x_pca = np.asarray(pca_adata.obsm["X_pca"], dtype=np.float32)
    pca_stats = finite_array_stats(x_pca, "expr_pca")
    pca_stats.update(before_scale_stats)
    pca_stats.update(after_scale_stats)
    pca_stats["expression_embedding_mode"] = "scale_then_pca"
    pca_stats["expr_pca_requested_n_comps"] = int(n_comps)
    pca_stats["expr_pca_actual_n_comps"] = int(actual_n_comps)
    pca_stats["expr_scale_max_value"] = float(scale_max_value)
    pca_stats["expr_pca_variance_ratio_sum"] = float(np.sum(pca_adata.uns["pca"]["variance_ratio"]))

    x_expr_sp = x_pca[:n_spatial, :]
    x_expr_sc = x_pca[n_spatial:, :]
    return x_expr_sp, x_expr_sc, pca_stats


def sampled_sqeuclidean_cost_stats(
    x: np.ndarray,
    y: np.ndarray,
    sample_size: int,
    seed: int,
    prefix: str,
) -> dict[str, float | int | bool]:
    rng = np.random.default_rng(seed)
    nx = x.shape[0]
    ny = y.shape[0]
    sx = min(sample_size, nx)
    sy = min(sample_size, ny)
    ix = rng.choice(nx, size=sx, replace=False)
    iy = rng.choice(ny, size=sy, replace=False)
    xs = np.asarray(x[ix], dtype=np.float32)
    ys = np.asarray(y[iy], dtype=np.float32)
    x2 = np.sum(xs * xs, axis=1, keepdims=True)
    y2 = np.sum(ys * ys, axis=1, keepdims=True).T
    cost = x2 + y2 - 2.0 * (xs @ ys.T)
    cost = np.maximum(cost, 0.0)
    out = {
        f"{prefix}_sample_n_source": int(sx),
        f"{prefix}_sample_n_target": int(sy),
    }
    out.update(finite_array_stats(cost, prefix))
    return out


def attach_spatial_coordinates(sp: sc.AnnData, cells_parquet: str) -> sc.AnnData:
    cells = pd.read_parquet(cells_parquet)
    need = {"cell_id", "x_centroid", "y_centroid"}
    miss = need - set(cells.columns)
    if miss:
        raise KeyError(f"cells.parquet missing columns: {miss}")

    tmp = cells[["cell_id", "x_centroid", "y_centroid"]].copy()
    tmp["cell_id"] = tmp["cell_id"].astype(str)
    tmp = tmp.drop_duplicates("cell_id").set_index("cell_id")

    sp = sp.copy()
    coords = tmp.reindex(sp.obs_names.astype(str))
    if coords.isna().any().any():
        n_missing = int(coords.isna().any(axis=1).sum())
        raise ValueError(f"Missing centroids for {n_missing} spatial cells")

    sp.obs["x_centroid"] = coords["x_centroid"].to_numpy(dtype=np.float32)
    sp.obs["y_centroid"] = coords["y_centroid"].to_numpy(dtype=np.float32)
    return sp


def choose_spatial_patch(sp: sc.AnnData, n_keep: int, mode: str, radius_um: float, seed: int) -> sc.AnnData:
    sp = sp.copy()
    x = sp.obs["x_centroid"].to_numpy()
    y = sp.obs["y_centroid"].to_numpy()
    x0 = np.median(x)
    y0 = np.median(y)

    if mode == "center_circle":
        d2 = (x - x0) ** 2 + (y - y0) ** 2
        mask = d2 <= (radius_um ** 2)
        idx = np.where(mask)[0]
        if idx.size < n_keep:
            order = np.argsort(d2)
            idx = order[:n_keep]
        else:
            idx = idx[:n_keep]
    elif mode == "random":
        rng = np.random.default_rng(seed)
        idx = rng.choice(sp.n_obs, size=min(n_keep, sp.n_obs), replace=False)
    else:
        # center_square: take nearest cells to center by Euclidean distance
        d2 = (x - x0) ** 2 + (y - y0) ** 2
        idx = np.argsort(d2)[: min(n_keep, sp.n_obs)]

    out = sp[idx].copy()
    print("[spatial patch]")
    print("mode:", mode)
    print("target n:", n_keep)
    print("selected n:", out.n_obs)
    print("center:", float(x0), float(y0))
    print("x range:", float(out.obs["x_centroid"].min()), float(out.obs["x_centroid"].max()))
    print("y range:", float(out.obs["y_centroid"].min()), float(out.obs["y_centroid"].max()))
    return out


def stratified_scrna_subset(sc_ref: sc.AnnData, n_keep: int, label_col: str, seed: int) -> sc.AnnData:
    if sc_ref.n_obs <= n_keep:
        return sc_ref.copy()

    rng = np.random.default_rng(seed)
    labels = sc_ref.obs[label_col].astype(str).to_numpy()
    vc = pd.Series(labels).value_counts()
    props = (vc / vc.sum()).sort_index()
    types = props.index.to_numpy()

    raw = props.to_numpy() * n_keep
    base = np.floor(raw).astype(int)
    remainder = raw - base

    need = n_keep - base.sum()
    if need > 0:
        add_order = np.argsort(-remainder)
        for i in add_order[:need]:
            base[i] += 1

    take_idx = []
    counts_target = dict(zip(types, base))
    for t in types:
        pool = np.where(labels == t)[0]
        k = min(counts_target[t], pool.size)
        chosen = rng.choice(pool, size=k, replace=False)
        take_idx.append(chosen)

    take_idx = np.concatenate(take_idx)
    if take_idx.size < n_keep:
        remaining = np.setdiff1d(np.arange(sc_ref.n_obs), take_idx, assume_unique=False)
        extra = rng.choice(remaining, size=(n_keep - take_idx.size), replace=False)
        take_idx = np.concatenate([take_idx, extra])

    out = sc_ref[take_idx].copy()
    print("[scRNA subset]")
    print("target n:", n_keep)
    print("selected n:", out.n_obs)
    print(out.obs[label_col].astype(str).value_counts())
    return out


# =========================================================
# 3) Load data
# =========================================================
if ARGS.spatial_input_h5ad:
    print("[spatial input h5ad]", ARGS.spatial_input_h5ad)
    print("[spatial input mode]", ARGS.spatial_input_mode)
    sp = sc.read_h5ad(ARGS.spatial_input_h5ad)
    sp.var_names_make_unique()
    sp.obs_names = sp.obs_names.astype(str)
    sp.var_names = sp.var_names.astype(str)
    if ARGS.spatial_input_mode == "raw_counts":
        sp = preprocess(sp)
    elif ARGS.spatial_input_mode == "existing_lognorm":
        sp = use_existing_lognorm(sp)
    elif ARGS.spatial_input_mode == "mass_match_reference_gene_sums":
        sp = mass_match_reference_gene_sums(sp, ARGS.spatial_reference_h5ad)
    else:
        raise ValueError(ARGS.spatial_input_mode)
else:
    sp = sc.read_10x_h5(f"{XENIUM_DIR}/cell_feature_matrix.h5")
    sp.var_names_make_unique()
    sp.obs_names = sp.obs_names.astype(str)

sc_ref = sc.read_10x_mtx(SCP_EXPR_DIR, var_names="gene_symbols", cache=False)
sc_ref.var_names_make_unique()
sc_ref.obs_names = sc_ref.obs_names.astype(str)

sc_ref = attach_scrna_metadata(sc_ref, SCP_META_CSV, SCRNA_CELLTYPE_COL)
sp = attach_spatial_labels(sp, XLSX_10X, XENIUM_SHEET, SPATIAL_CELLTYPE_COL)
sp = attach_spatial_coordinates(sp, CELLS_PARQUET)

# =========================================================
# 4) Shared genes
# =========================================================
shared = np.intersect1d(sp.var_names, sc_ref.var_names)
print(f"Shared genes: {len(shared)}")
sp = sp[:, shared].copy()
sc_ref = sc_ref[:, shared].copy()

# =========================================================
# 5) Patch / subset
# =========================================================
sp = choose_spatial_patch(sp, N_SPATIAL, PATCH_MODE, PATCH_RADIUS_UM, RNG_SEED)
sc_ref = stratified_scrna_subset(sc_ref, N_SCRNA, SCRNA_CELLTYPE_COL, RNG_SEED)

print(f"Spatial cells: {sp.n_obs}, scRNA cells: {sc_ref.n_obs}")
print(f"Using scRNA cell-type column: {SCRNA_CELLTYPE_COL}")
print(f"Using spatial grouping column: {SPATIAL_CELLTYPE_COL}")

# =========================================================
# 6) Preprocess
# =========================================================
if not ARGS.spatial_input_h5ad:
    sp = preprocess(sp)
sc_ref = preprocess(sc_ref)

sp.write_h5ad(OUT_SP_ORIG)
print("Saved:", OUT_SP_ORIG)

X_sc = np.asarray(sc_ref.X, dtype=np.float32)
X_sp = np.asarray(sp.X, dtype=np.float32)
sp_labels = sp.obs[SPATIAL_CELLTYPE_COL].astype(str).to_numpy()
sc_labels = sc_ref.obs[SCRNA_CELLTYPE_COL].astype(str).to_numpy()

# =========================================================
# 7) Build unweighted binary structural term and type-balanced marginals
# =========================================================
all_types_union = sorted(set(sp_labels.tolist()) | set(sc_labels.tolist()))
print(f"n_union_types_for_structure = {len(all_types_union)}")

Z_sp = make_binary_structural_embedding(sp_labels, all_types_union)
Z_sc = make_binary_structural_embedding(sc_labels, all_types_union)
sp_struct_cell_weight = np.ones(sp.n_obs, dtype=np.float32)
sc_struct_cell_weight = np.ones(sc_ref.n_obs, dtype=np.float32)
sp_struct_type_weight = {str(t): 1.0 for t in np.unique(sp_labels)}
sc_struct_type_weight = {str(t): 1.0 for t in np.unique(sc_labels)}

sp_marginal, sp_marginal_type_counts, sp_marginal_type_total_mass = make_type_balanced_marginal(sp_labels)
sc_marginal, sc_marginal_type_counts, sc_marginal_type_total_mass = make_type_balanced_marginal(sc_labels)

sp.obs["fgw_struct_celltype_weight"] = sp_struct_cell_weight
sc_ref.obs["fgw_struct_celltype_weight"] = sc_struct_cell_weight
sp.obs["fgw_typebalanced_marginal"] = sp_marginal
sc_ref.obs["fgw_typebalanced_marginal"] = sc_marginal

print("[structural weights: unweighted one-hot]")
print("spatial min/median/max:", float(sp_struct_cell_weight.min()), float(np.median(sp_struct_cell_weight)), float(sp_struct_cell_weight.max()))
print("scRNA min/median/max:", float(sc_struct_cell_weight.min()), float(np.median(sc_struct_cell_weight)), float(sc_struct_cell_weight.max()))
print("[type-balanced marginals]")
print("spatial sum/min/median/max:", float(sp_marginal.sum()), float(sp_marginal.min()), float(np.median(sp_marginal)), float(sp_marginal.max()))
print("scRNA sum/min/median/max:", float(sc_marginal.sum()), float(sc_marginal.min()), float(np.median(sc_marginal)), float(sc_marginal.max()))

# =========================================================
# 8) Build combined AnnData for FGW
# =========================================================
adata = sc.concat(
    [sp, sc_ref],
    label="domain",
    keys=["spatial", "scrna"],
    join="inner",
    index_unique=None,
)

X_expr_sp, X_expr_sc, expression_embedding_diagnostics = build_pca_expression_embedding(
    adata=adata,
    n_spatial=sp.n_obs,
    n_comps=EXPR_PCA_N_COMPS,
    scale_max_value=EXPR_SCALE_MAX_VALUE,
    seed=RNG_SEED,
)
adata.obsm["X_expr"] = np.vstack([X_expr_sp, X_expr_sc]).astype(np.float32)
adata.obsm["X_struct"] = np.vstack([Z_sp, Z_sc]).astype(np.float32)

print("adata shape:", adata.shape)
print("X_expr shape:", adata.obsm["X_expr"].shape)
print("X_expr mode: scale_then_pca")
print("X_expr PCA variance ratio sum:", expression_embedding_diagnostics["expr_pca_variance_ratio_sum"])
print("X_struct shape:", adata.obsm["X_struct"].shape)

cost_diagnostics: dict[str, float | int | bool] = {}
cost_diagnostics.update(
    sampled_sqeuclidean_cost_stats(
        X_expr_sp,
        X_expr_sc,
        sample_size=ARGS.cost_sample_size,
        seed=RNG_SEED,
        prefix="expression_cost_sample",
    )
)
cost_diagnostics.update(
    sampled_sqeuclidean_cost_stats(
        Z_sp,
        Z_sc,
        sample_size=ARGS.cost_sample_size,
        seed=RNG_SEED + 1,
        prefix="structural_cost_sample",
    )
)
expr_p99 = float(cost_diagnostics.get("expression_cost_sample_p99", np.nan))
struct_p99 = float(cost_diagnostics.get("structural_cost_sample_p99", np.nan))
effective_p99 = (1.0 - ALPHA) * expr_p99 + ALPHA * struct_p99
cost_diagnostics["effective_cost_sample_p99_approx"] = float(effective_p99)
cost_diagnostics["effective_cost_over_epsilon_p99_approx"] = float(effective_p99 / EPSILON) if EPSILON > 0 else np.nan
cost_diagnostics["effective_cost_over_epsilon_normalized_p99_approx"] = (
    float(effective_p99 / EPSILON_NORMALIZED) if EPSILON_NORMALIZED > 0 else np.nan
)

print("[sampled cost diagnostics]")
print("expression cost p50/p95/p99/max:",
      cost_diagnostics.get("expression_cost_sample_median"),
      cost_diagnostics.get("expression_cost_sample_p95"),
      cost_diagnostics.get("expression_cost_sample_p99"),
      cost_diagnostics.get("expression_cost_sample_max"))
print("structural cost p50/p95/p99/max:",
      cost_diagnostics.get("structural_cost_sample_median"),
      cost_diagnostics.get("structural_cost_sample_p95"),
      cost_diagnostics.get("structural_cost_sample_p99"),
      cost_diagnostics.get("structural_cost_sample_max"))
print("approx effective p99 / epsilon:", cost_diagnostics["effective_cost_over_epsilon_p99_approx"])

# =========================================================
# 9) Solve FGW
# =========================================================
fgw = FGWProblem(adata)

fgw = fgw.prepare(
    key="domain",
    policy="explicit",
    subset=[("spatial", "scrna")],
    joint_attr="X_expr",
    x_attr="X_struct",
    y_attr="X_struct",
    cost={
        "xy": LINEAR_COST,
        "x": STRUCT_COST,
        "y": STRUCT_COST,
    },
    a="fgw_typebalanced_marginal",
    b="fgw_typebalanced_marginal",
)

fgw = fgw.solve(
    alpha=ALPHA,
    epsilon=EPSILON,
    tau_a=TAU_A,
    tau_b=TAU_B,
    rank=RANK,
    batch_size=BATCH_SIZE,
    scale_cost=SCALE_COST,
)

# =========================================================
# 10) Coupling representation
# =========================================================
sol = fgw[("spatial", "scrna")].solution
ott_output = getattr(sol, "_output", None)
use_lowrank_factors = all(hasattr(ott_output, name) for name in ("q", "r", "g"))

if use_lowrank_factors:
    # Do not instantiate sol.transport_matrix for all-cells low-rank runs.
    # Dense P would be n_spatial x n_scrna, about 57 GB for this dataset.
    q = np.asarray(ott_output.q, dtype=np.float32)
    r = np.asarray(ott_output.r, dtype=np.float32)
    g = np.asarray(ott_output.g, dtype=np.float32)
    inv_g = (1.0 / g.astype(np.float64)).astype(np.float32)

    coupling_shape = (int(q.shape[0]), int(r.shape[0]))
    row_mass = (q @ (r.sum(axis=0).astype(np.float32) * inv_g)).astype(np.float32)
    coupling_sum = float(row_mass.sum())
    coupling_dense_nbytes_float32 = int(np.prod(coupling_shape) * np.dtype(np.float32).itemsize)
    coupling_diagnostics = {
        "coupling_representation": "lowrank_factors_q_r_g",
        "coupling_shape_0": coupling_shape[0],
        "coupling_shape_1": coupling_shape[1],
        "coupling_rank_factor": int(q.shape[1]),
        "coupling_sum_from_row_mass": coupling_sum,
        "coupling_dense_nbytes_float32_if_materialized": coupling_dense_nbytes_float32,
    }
    coupling_diagnostics.update(finite_array_stats(q, "coupling_q_factor"))
    coupling_diagnostics.update(finite_array_stats(r, "coupling_r_factor"))
    coupling_diagnostics.update(finite_array_stats(g, "coupling_g_factor"))
    print("P low-rank factors:", "q", q.shape, "r", r.shape, "g", g.shape, "sum:", coupling_sum)
else:
    P = np.asarray(sol.transport_matrix, dtype=np.float32)
    coupling_shape = P.shape
    coupling_sum = float(P.sum())
    coupling_dense_nbytes_float32 = int(P.nbytes)
    print("P shape:", P.shape, "sum:", coupling_sum)
    coupling_diagnostics = {
        "coupling_representation": "dense_matrix",
        "coupling_dense_nbytes_float32_if_materialized": coupling_dense_nbytes_float32,
    }
    coupling_diagnostics.update(finite_array_stats(P, "coupling"))
    row_mass = P.sum(axis=1).astype(np.float32)

print("[coupling finite diagnostics]")
print("representation:", coupling_diagnostics["coupling_representation"])
print("dense float32 bytes if materialized:", coupling_dense_nbytes_float32)
print("row mass finite:", bool(np.isfinite(row_mass).all()))

uniform_source_row_mass = np.float32(1.0 / float(sp.n_obs))
source_marginal = sp_marginal.astype(np.float32)
scrna_blend_fraction = unbalanced_scrna_blend_fraction(row_mass, source_marginal)

if use_lowrank_factors:
    np.savez_compressed(
        OUT_COUPLING_NPZ,
        q=q,
        r=r,
        g=g,
        row_mass=row_mass,
        source_marginal=source_marginal,
        target_marginal=sc_marginal.astype(np.float32),
        uniform_source_row_mass=uniform_source_row_mass,
        scrna_blend_fraction=scrna_blend_fraction,
        sp_struct_cell_weight=sp_struct_cell_weight,
        sc_struct_cell_weight=sc_struct_cell_weight,
        coupling_representation=np.array("lowrank_factors_q_r_g"),
    )
else:
    np.savez_compressed(
        OUT_COUPLING_NPZ,
        P=P,
        row_mass=row_mass,
        source_marginal=source_marginal,
        target_marginal=sc_marginal.astype(np.float32),
        uniform_source_row_mass=uniform_source_row_mass,
        scrna_blend_fraction=scrna_blend_fraction,
        sp_struct_cell_weight=sp_struct_cell_weight,
        sc_struct_cell_weight=sc_struct_cell_weight,
        coupling_representation=np.array("dense_matrix"),
    )
print("Saved:", OUT_COUPLING_NPZ)

row_sum_safe = row_mass.astype(np.float32).copy()
row_sum_safe[row_sum_safe == 0] = 1.0


def lowrank_row_normalized_apply(target_matrix: np.ndarray) -> np.ndarray:
    target_matrix = np.asarray(target_matrix, dtype=np.float32)
    projected = (r.T @ target_matrix).astype(np.float32)
    projected = projected * inv_g[:, None]
    out = (q @ projected).astype(np.float32)
    out = out / row_sum_safe[:, None]
    return out

print("[unbalanced row mass]")
print("uniform source row mass:", float(uniform_source_row_mass))
print("source marginal min/median/max:", float(source_marginal.min()), float(np.median(source_marginal)), float(source_marginal.max()))
print("row mass min/median/max:", float(row_mass.min()), float(np.median(row_mass)), float(row_mass.max()))
print("scRNA blend fraction min/median/max:", float(scrna_blend_fraction.min()), float(np.median(scrna_blend_fraction)), float(scrna_blend_fraction.max()))

# =========================================================
# 11) FGW barycentric output with unbalanced residual kept as spatial expression
# =========================================================
if use_lowrank_factors:
    X_scrna_fgw = lowrank_row_normalized_apply(X_sc)
else:
    P_row = P / row_sum_safe[:, None]
    X_scrna_fgw = P_row @ X_sc
lambda_sc = scrna_blend_fraction[:, None]
X_soft_fgw = lambda_sc * X_scrna_fgw + (1.0 - lambda_sc) * X_sp
soft_diagnostics = finite_array_stats(X_soft_fgw, "soft_expression")
soft_gene_var = np.nanvar(X_soft_fgw, axis=0)
original_gene_var = np.nanvar(X_sp, axis=0)
soft_cell_total = np.nansum(X_soft_fgw, axis=1)
original_cell_total = np.nansum(X_sp, axis=1)

sp_soft_fgw = sp.copy()
sp_soft_fgw.X = X_soft_fgw.astype(np.float32)
rank_mode = "fullrank" if RANK == -1 else f"lowrank{RANK}"
sp_soft_fgw.obs["impute_mode"] = (
    f"soft_barycentric_fgw_unweightedstruct_typebalancedmarginal_"
    f"unbalancedblend_patch_{rank_mode}"
)
sp_soft_fgw.obs["fgw_row_mass"] = row_mass
sp_soft_fgw.obs["fgw_source_marginal"] = source_marginal
sp_soft_fgw.obs["fgw_uniform_source_row_mass"] = uniform_source_row_mass
sp_soft_fgw.obs["fgw_scrna_blend_fraction"] = scrna_blend_fraction
sp_soft_fgw.write_h5ad(OUT_SP_SOFT_FGW)
print("Saved:", OUT_SP_SOFT_FGW)

# =========================================================
# 12) Lightweight group-to-type mass diagnostics
# =========================================================
types, inverse = np.unique(sc_labels, return_inverse=True)
n_types = len(types)
print(f"n_scRNA_types = {n_types}")
print("scRNA types:", types.tolist())

G = np.zeros((sc_ref.n_obs, n_types), dtype=np.float32)
G[np.arange(sc_ref.n_obs), inverse] = 1.0

if use_lowrank_factors:
    type_mass_cell = lowrank_row_normalized_apply(G)
else:
    type_mass_cell = P_row @ G

unique_sp_groups = pd.Index(pd.Categorical(sp_labels).categories).astype(str).tolist()
summary_rows = []

for g in unique_sp_groups:
    rows = np.where(sp_labels == g)[0]
    if rows.size == 0:
        continue

    group_scores_raw = type_mass_cell[rows, :].sum(axis=0).astype(np.float64)
    score_sum = float(group_scores_raw.sum())
    if np.isfinite(score_sum) and score_sum > 0:
        group_scores_frac = group_scores_raw / score_sum
    else:
        group_scores_frac = np.full_like(group_scores_raw, np.nan, dtype=np.float64)

    best_k = int(np.nanargmax(group_scores_frac)) if np.isfinite(group_scores_frac).any() else 0
    row_dict = {
        "spatial_group": g,
        "n_cells": int(rows.size),
        "raw_mass_sum": score_sum,
        "top_scrna_type": str(types[best_k]),
        "top_scrna_type_fraction": float(group_scores_frac[best_k]),
    }
    for k, ct in enumerate(types):
        row_dict[f"raw_mass_{ct}"] = float(group_scores_raw[k])
        row_dict[f"fraction_{ct}"] = float(group_scores_frac[k])
    summary_rows.append(row_dict)

summary_df = pd.DataFrame(summary_rows)
summary_df.to_csv(OUT_GROUP_TYPE_MASS, index=False)
print("Saved:", OUT_GROUP_TYPE_MASS)
group_top_type_counts = (
    {str(k): int(v) for k, v in summary_df["top_scrna_type"].value_counts().items()}
    if not summary_df.empty else {}
)
group_top_type_fraction_max = (
    float(summary_df["top_scrna_type"].value_counts(normalize=True).iloc[0])
    if not summary_df.empty else np.nan
)

summary = {
    "mode": "fgw54_debug_unweighted_structure_typebalanced_marginal_unbalanced_blend",
    "run_tag": RUN_TAG,
    "solver_rank_mode": "full_rank" if RANK == -1 else "low_rank",
    "n_spatial": int(sp.n_obs),
    "n_scrna": int(sc_ref.n_obs),
    "n_genes": int(sp.n_vars),
    "n_union_types_for_structure": int(len(all_types_union)),
    "structural_weight_rule": "unweighted union one-hot; one-hot coordinate = 1 / sqrt(2)",
    "marginal_rule": "each observed label has total mass 1 / n_labels in its own domain; cells within each label split that mass uniformly",
    "alpha": ALPHA,
    "epsilon_normalized": EPSILON_NORMALIZED,
    "epsilon_alpha_correction": EPSILON_ALPHA_CORRECTION,
    "epsilon_alpha_multiplier": EPSILON_ALPHA_MULTIPLIER,
    "epsilon_to_solver": EPSILON,
    "epsilon": EPSILON,
    "tau_a": TAU_A,
    "tau_b": TAU_B,
    "rank": RANK,
    "batch_size": BATCH_SIZE,
    "scale_cost": SCALE_COST,
    "expression_embedding_mode": "scale_then_pca",
    "expression_embedding_note": "FGW expression cost uses Scanpy scale(max_value) followed by PCA on concatenated spatial+scRNA cells; barycentric output remains in log-normalized gene space.",
    "expr_pca_n_comps": int(EXPR_PCA_N_COMPS),
    "expr_scale_max_value": float(EXPR_SCALE_MAX_VALUE),
    "patch_mode": PATCH_MODE,
    "patch_radius_um": PATCH_RADIUS_UM,
    "cost_sample_size": int(ARGS.cost_sample_size),
    "coupling_shape": [int(coupling_shape[0]), int(coupling_shape[1])],
    "coupling_sum": float(coupling_sum),
    "coupling_nbytes_float32": int(coupling_dense_nbytes_float32),
    "coupling_dense_materialized": bool(not use_lowrank_factors),
    "uniform_source_row_mass": float(uniform_source_row_mass),
    "source_marginal_min": float(source_marginal.min()),
    "source_marginal_median": float(np.median(source_marginal)),
    "source_marginal_max": float(source_marginal.max()),
    "target_marginal_min": float(sc_marginal.min()),
    "target_marginal_median": float(np.median(sc_marginal)),
    "target_marginal_max": float(sc_marginal.max()),
    "row_mass_min": float(row_mass.min()),
    "row_mass_median": float(np.median(row_mass)),
    "row_mass_max": float(row_mass.max()),
    "scrna_blend_fraction_min": float(scrna_blend_fraction.min()),
    "scrna_blend_fraction_median": float(np.median(scrna_blend_fraction)),
    "scrna_blend_fraction_max": float(scrna_blend_fraction.max()),
    "sp_struct_weight_min": float(sp_struct_cell_weight.min()),
    "sp_struct_weight_median": float(np.median(sp_struct_cell_weight)),
    "sp_struct_weight_max": float(sp_struct_cell_weight.max()),
    "sc_struct_weight_min": float(sc_struct_cell_weight.min()),
    "sc_struct_weight_median": float(np.median(sc_struct_cell_weight)),
    "sc_struct_weight_max": float(sc_struct_cell_weight.max()),
    "sp_struct_type_weight": {str(k): float(v) for k, v in sp_struct_type_weight.items()},
    "sc_struct_type_weight": {str(k): float(v) for k, v in sc_struct_type_weight.items()},
    "sp_marginal_type_counts": {str(k): int(v) for k, v in sp_marginal_type_counts.items()},
    "sc_marginal_type_counts": {str(k): int(v) for k, v in sc_marginal_type_counts.items()},
    "sp_marginal_type_total_mass": {str(k): float(v) for k, v in sp_marginal_type_total_mass.items()},
    "sc_marginal_type_total_mass": {str(k): float(v) for k, v in sc_marginal_type_total_mass.items()},
    "x_expr_shape": [int(adata.obsm["X_expr"].shape[0]), int(adata.obsm["X_expr"].shape[1])],
    "x_struct_shape": [int(adata.obsm["X_struct"].shape[0]), int(adata.obsm["X_struct"].shape[1])],
    "soft_gene_var_mean": float(np.nanmean(soft_gene_var)),
    "soft_gene_var_median": float(np.nanmedian(soft_gene_var)),
    "original_gene_var_mean": float(np.nanmean(original_gene_var)),
    "original_gene_var_median": float(np.nanmedian(original_gene_var)),
    "soft_gene_var_mean_ratio_to_original": float(np.nanmean(soft_gene_var) / np.nanmean(original_gene_var)),
    "soft_cell_total_std": float(np.nanstd(soft_cell_total)),
    "original_cell_total_std": float(np.nanstd(original_cell_total)),
    "soft_cell_total_std_ratio_to_original": float(np.nanstd(soft_cell_total) / np.nanstd(original_cell_total)),
    "group_top_type_counts": group_top_type_counts,
    "group_top_type_fraction_max": group_top_type_fraction_max,
}
summary.update(expression_embedding_diagnostics)
summary.update(cost_diagnostics)
summary.update(coupling_diagnostics)
summary.update(soft_diagnostics)
with open(OUT_RUN_SUMMARY, "w") as f:
    json.dump(summary, f, indent=2)
print("Saved:", OUT_RUN_SUMMARY)

print("FGW unbalanced-blended soft mean:", float(X_soft_fgw.mean()))
print("DONE.")

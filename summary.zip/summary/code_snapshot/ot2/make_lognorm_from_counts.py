#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import json
import os

import scanpy as sc


def main() -> None:
    parser = argparse.ArgumentParser(description="Create a log-normalized h5ad from an OT2 hard-count cell-by-gene h5ad.")
    parser.add_argument("--counts_h5ad", required=True)
    parser.add_argument("--out_h5ad", required=True)
    parser.add_argument("--target_sum", type=float, default=1e4)
    args = parser.parse_args()

    adata = sc.read_h5ad(args.counts_h5ad)
    adata.obs_names = adata.obs_names.astype(str)
    adata.var_names = adata.var_names.astype(str)
    adata.layers["counts"] = adata.X.copy()
    sc.pp.normalize_total(adata, target_sum=args.target_sum)
    sc.pp.log1p(adata)
    adata.uns["ot2_hardcount_lognorm"] = {
        "source_counts_h5ad": args.counts_h5ad,
        "target_sum": float(args.target_sum),
    }

    os.makedirs(os.path.dirname(os.path.abspath(args.out_h5ad)), exist_ok=True)
    adata.write_h5ad(args.out_h5ad)

    summary = {
        "counts_h5ad": args.counts_h5ad,
        "out_h5ad": args.out_h5ad,
        "n_cells": int(adata.n_obs),
        "n_genes": int(adata.n_vars),
        "target_sum": float(args.target_sum),
    }
    summary_path = os.path.splitext(args.out_h5ad)[0] + "_summary.json"
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)
    print("Saved:", args.out_h5ad)
    print("Saved:", summary_path)


if __name__ == "__main__":
    main()


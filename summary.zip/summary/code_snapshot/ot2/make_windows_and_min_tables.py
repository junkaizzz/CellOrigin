#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Preprocess step:
- Read transcripts.parquet and cells.parquet
- Build a stable minimal transcripts table with mol_id,gene,x,y (transcripts_min.parquet)
- Build minimal cells table cell_id,x,y (cells_min.parquet)
- Build sliding windows covering the global bbox, with overlap and a padded bbox for candidate cells
- Save windows.csv
"""

import os, json, argparse
import numpy as np
import pandas as pd


def _find_first(cols, candidates):
    for c in candidates:
        if c in cols:
            return c
    return None


def load_transcripts_min(transcripts_parq: str) -> pd.DataFrame:
    df = pd.read_parquet(transcripts_parq)
    cols = set(df.columns)

    id_col = _find_first(cols, ["transcript_id", "molecule_id", "moleculeid", "transcriptid", "id"])
    gene_col = _find_first(cols, ["feature_name", "gene", "gene_name", "feature", "target_name"])
    x_col = _find_first(cols, ["x_location", "x", "x_centroid", "x_um", "xcoord", "x_coord"])
    y_col = _find_first(cols, ["y_location", "y", "y_centroid", "y_um", "ycoord", "y_coord"])

    if gene_col is None or x_col is None or y_col is None:
        raise KeyError(
            f"Cannot detect transcript columns. Found={sorted(list(cols))}\n"
            f"Need gene and x/y columns."
        )

    keep = [gene_col, x_col, y_col]
    if id_col is not None:
        keep = [id_col] + keep

    out = df[keep].copy()
    if id_col is None:
        out.insert(0, "mol_id", np.arange(len(out), dtype=np.int64))
    else:
        out = out.rename(columns={id_col: "mol_id"})

    out = out.rename(columns={gene_col: "gene", x_col: "x", y_col: "y"})
    out["gene"] = out["gene"].astype(str)
    out["x"] = pd.to_numeric(out["x"], errors="coerce")
    out["y"] = pd.to_numeric(out["y"], errors="coerce")
    out = out.dropna(subset=["mol_id", "gene", "x", "y"])

    out["mol_id"] = pd.to_numeric(out["mol_id"], errors="coerce").astype("Int64")
    out = out.dropna(subset=["mol_id"]).copy()
    out["mol_id"] = out["mol_id"].astype(np.int64)

    return out[["mol_id", "gene", "x", "y"]]


def load_cells_min(cells_parq: str) -> pd.DataFrame:
    df = pd.read_parquet(cells_parq)
    cols = set(df.columns)

    id_col = _find_first(cols, ["cell_id", "cellid", "barcode", "CellID", "Cell_Id"])
    x_col = _find_first(cols, ["x_centroid", "x", "centroid_x", "x_center", "x_um"])
    y_col = _find_first(cols, ["y_centroid", "y", "centroid_y", "y_center", "y_um"])

    if id_col is None or x_col is None or y_col is None:
        raise KeyError(
            f"Cannot detect cell centroid columns. Found={sorted(list(cols))}\n"
            f"Need cell_id and centroid x/y columns."
        )

    out = df[[id_col, x_col, y_col]].copy()
    out = out.rename(columns={id_col: "cell_id", x_col: "x", y_col: "y"})
    out["cell_id"] = out["cell_id"].astype(str)
    out["x"] = pd.to_numeric(out["x"], errors="coerce")
    out["y"] = pd.to_numeric(out["y"], errors="coerce")
    out = out.dropna(subset=["cell_id", "x", "y"])
    return out[["cell_id", "x", "y"]]


def make_windows(xmin, ymin, xmax, ymax, window_size, step, pad):
    def starts(vmin, vmax):
        if vmax - vmin <= window_size:
            return np.array([vmin], dtype=np.float64)
        arr = np.arange(vmin, vmax - window_size + 1e-9, step, dtype=np.float64)
        last = vmax - window_size
        if len(arr) == 0 or abs(arr[-1] - last) > 1e-6:
            arr = np.append(arr, last)
        return arr

    xs = starts(xmin, xmax)
    ys = starts(ymin, ymax)

    rows = []
    wid = 0
    for x0 in xs:
        for y0 in ys:
            x1 = x0 + window_size
            y1 = y0 + window_size
            rows.append({
                "window_id": wid,
                "x0": float(x0), "y0": float(y0),
                "x1": float(x1), "y1": float(y1),
                "xp0": float(x0 - pad), "yp0": float(y0 - pad),
                "xp1": float(x1 + pad), "yp1": float(y1 + pad),
            })
            wid += 1
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--transcripts_parq", required=True)
    ap.add_argument("--cells_parq", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--window_size_um", type=float, default=250.0)
    ap.add_argument("--step_um", type=float, default=125.0)
    ap.add_argument("--pad_um", type=float, default=60.0)
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    tx = load_transcripts_min(args.transcripts_parq)
    cells = load_cells_min(args.cells_parq)

    xmin = float(min(tx["x"].min(), cells["x"].min()))
    ymin = float(min(tx["y"].min(), cells["y"].min()))
    xmax = float(max(tx["x"].max(), cells["x"].max()))
    ymax = float(max(tx["y"].max(), cells["y"].max()))

    windows = make_windows(
        xmin, ymin, xmax, ymax,
        window_size=float(args.window_size_um),
        step=float(args.step_um),
        pad=float(args.pad_um),
    )

    tx_out = os.path.join(args.out_dir, "transcripts_min.parquet")
    cells_out = os.path.join(args.out_dir, "cells_min.parquet")
    win_out = os.path.join(args.out_dir, "windows.csv")

    tx.to_parquet(tx_out, index=False)
    cells.to_parquet(cells_out, index=False)
    windows.to_csv(win_out, index=False)

    cfg = {
        "transcripts_parq": args.transcripts_parq,
        "cells_parq": args.cells_parq,
        "out_dir": args.out_dir,
        "window_size_um": args.window_size_um,
        "step_um": args.step_um,
        "pad_um": args.pad_um,
        "bbox": {"xmin": xmin, "ymin": ymin, "xmax": xmax, "ymax": ymax},
        "n_windows": int(len(windows)),
        "n_transcripts": int(len(tx)),
        "n_cells": int(len(cells)),
        "timestamp": pd.Timestamp.now().isoformat(),
    }
    with open(os.path.join(args.out_dir, "preprocess_config.json"), "w") as f:
        json.dump(cfg, f, indent=2)

    print("Wrote:")
    print(" ", tx_out)
    print(" ", cells_out)
    print(" ", win_out)
    print("n_windows =", len(windows))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Merge step:
- Read all worker_out/window_*/assignments.parquet
- Resolve overlaps: per mol_id keep row with max(assign_conf)
- Produce:
  - final molecule assignments (one row per mol_id)
  - cell-gene counts
  - AnnData cell x gene matrix (integer counts) aligned to OT1 soft cell order and gene set
"""

import os, json, argparse, glob
import numpy as np
import pandas as pd

import scanpy as sc
import anndata as ad
import scipy.sparse as sp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run_dir", required=True)
    ap.add_argument("--ot1_soft_h5ad", required=True)
    ap.add_argument("--out_prefix", default="ot2_window_final")
    args = ap.parse_args()

    run_dir = args.run_dir
    out_root = os.path.join(run_dir, "worker_out")
    files = sorted(glob.glob(os.path.join(out_root, "window_*", "assignments.parquet")))
    if len(files) == 0:
        raise FileNotFoundError(f"No assignments.parquet found under {out_root}")

    ad_soft = sc.read_h5ad(args.ot1_soft_h5ad)
    ad_soft.obs_names = ad_soft.obs_names.astype(str)
    cells = ad_soft.obs_names.to_numpy()
    genes = ad_soft.var_names.to_numpy()

    dfs = []
    total_rows = 0
    for fp in files:
        df = pd.read_parquet(fp)
        dfs.append(df)
        total_rows += len(df)
    all_df = pd.concat(dfs, ignore_index=True)

    all_df["assigned_cell"] = all_df["assigned_cell"].astype(str)
    all_df["gene"] = all_df["gene"].astype(str)

    all_df = all_df.loc[
        all_df["assigned_cell"].isin(set(cells)) &
        all_df["gene"].isin(set(genes))
    ].copy()

    all_df.sort_values(["mol_id", "assign_conf"], ascending=[True, False], inplace=True)
    best_df = all_df.drop_duplicates(subset=["mol_id"], keep="first").copy()

    mol_out = os.path.join(run_dir, f"{args.out_prefix}_molecule_assignments.parquet")
    best_df.to_parquet(mol_out, index=False)

    cg = best_df.groupby(["assigned_cell", "gene"]).size().reset_index(name="count")
    cg_out = os.path.join(run_dir, f"{args.out_prefix}_cell_gene_counts.parquet")
    cg.to_parquet(cg_out, index=False)

    cell_index = {c: i for i, c in enumerate(cells)}
    gene_index = {g: j for j, g in enumerate(genes)}

    row = cg["assigned_cell"].map(cell_index).to_numpy(dtype=np.int64)
    col = cg["gene"].map(gene_index).to_numpy(dtype=np.int64)
    data = cg["count"].to_numpy(dtype=np.int32)

    X = sp.csr_matrix((data, (row, col)), shape=(len(cells), len(genes)), dtype=np.int32)

    adata = ad.AnnData(X=X, obs=ad_soft.obs.copy(), var=ad_soft.var.copy())
    if "spatial" in ad_soft.obsm:
        adata.obsm["spatial"] = ad_soft.obsm["spatial"].copy()

    h5ad_out = os.path.join(run_dir, f"{args.out_prefix}_cell_by_gene.h5ad")
    adata.write_h5ad(h5ad_out)

    summary = {
        "n_assignment_files": int(len(files)),
        "total_window_rows": int(total_rows),
        "rows_after_filter_to_ot1": int(len(all_df)),
        "unique_molecules_final": int(best_df["mol_id"].nunique()),
        "unique_cells_used": int(best_df["assigned_cell"].nunique()),
        "unique_genes_used": int(best_df["gene"].nunique()),
        "outputs": {
            "molecule_assignments": mol_out,
            "cell_gene_counts": cg_out,
            "cell_by_gene_h5ad": h5ad_out,
        }
    }
    with open(os.path.join(run_dir, f"{args.out_prefix}_merge_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    print("Wrote:")
    print(" ", mol_out)
    print(" ", cg_out)
    print(" ", h5ad_out)


if __name__ == "__main__":
    main()

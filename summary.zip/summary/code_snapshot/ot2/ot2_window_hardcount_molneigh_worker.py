#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OT2 sliding-window hard-count worker using molecule-neighborhood candidates.

Each run processes a range of windows [start,end] (inclusive).
Within each window:
- molecules: transcripts in bbox [x0,y0,x1,y1]
- candidate cells: union of cells within hard_cut_um of molecules for each gene/window
- per gene: unbalanced Sinkhorn from molecules -> cells
- save per-molecule argmax assignment with confidence

Overlap handling is done later by merge_window_assignments.py
"""

import os, json, argparse
import numpy as np
import pandas as pd

# Keep per-job threads small; rely on job-array parallelism
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("JAX_PLATFORM_NAME", "cpu")

import jax
import jax.numpy as jnp
import scanpy as sc
from scipy.spatial import cKDTree

from ott.problems.linear import linear_problem
from ott.solvers.linear import sinkhorn
from ott.geometry import pointcloud
from ott.geometry import costs


EPS_SAFE = 1e-12


def sinkhorn_diagnostics(out, max_iters: int, threshold: float) -> dict:
    """Extract convergence diagnostics from an OTT SinkhornOutput."""
    converged = getattr(out, "converged", None)
    if converged is None:
        converged_value = False
    else:
        converged_value = bool(np.asarray(jax.device_get(converged)).item())

    n_iters = getattr(out, "n_iters", None)
    if n_iters is None:
        n_iters_value = -1
    else:
        n_iters_value = int(np.asarray(jax.device_get(n_iters)).item())

    errors = getattr(out, "errors", None)
    if errors is None:
        last_error = np.nan
        min_error = np.nan
        error_entries_used = 0
    else:
        err = np.asarray(jax.device_get(errors), dtype=np.float64).ravel()
        used = err[err != -1]
        finite = used[np.isfinite(used) & (used >= 0)]
        error_entries_used = int(used.size)
        if finite.size:
            last_error = float(finite[-1])
            min_error = float(finite.min())
        else:
            last_error = np.nan
            min_error = np.nan

    return {
        "sinkhorn_converged": converged_value,
        "sinkhorn_n_iters": n_iters_value,
        "sinkhorn_reached_max_iters": bool(n_iters_value >= int(max_iters)),
        "sinkhorn_last_error": last_error,
        "sinkhorn_min_error": min_error,
        "sinkhorn_error_entries_used": error_entries_used,
        "sinkhorn_threshold": float(threshold),
        "sinkhorn_max_iters": int(max_iters),
    }


@jax.tree_util.register_pytree_node_class
class HingeExpDistanceCost(costs.CostFn):
    """
    0-R0 um:   (d / R0)^P_IN
    >R0 um:    (d / R0)^P_IN + ALPHA * (exp((d-R0)/SIGMA) - 1)
    """
    def __init__(self, r0, sigma, alpha, p):
        super().__init__()
        self.r0 = jnp.asarray(r0)
        self.sigma = jnp.asarray(sigma)
        self.alpha = jnp.asarray(alpha)
        self.p = jnp.asarray(p)

    def __call__(self, x, y):
        d = jnp.linalg.norm(x - y)
        base = (d / self.r0) ** self.p
        extra = self.alpha * jnp.expm1(jnp.maximum(d - self.r0, 0.0) / self.sigma)
        return base + extra

    def tree_flatten(self):
        return (self.r0, self.sigma, self.alpha, self.p), None

    @classmethod
    def tree_unflatten(cls, aux, children):
        r0, sigma, alpha, p = children
        return cls(r0, sigma, alpha, p)


@jax.tree_util.register_pytree_node_class
class HardCutHingeExpDistanceCost(costs.CostFn):
    """
    Hinge-exp distance cost inside hard_cut_um, with a large penalty outside.
    This matches the local-candidate logic used by the OT12 all-window OT2 code.
    """

    def __init__(self, r0, sigma, alpha, p, hard_cut_um, big_penalty):
        super().__init__()
        self.r0 = jnp.asarray(r0)
        self.sigma = jnp.asarray(sigma)
        self.alpha = jnp.asarray(alpha)
        self.p = jnp.asarray(p)
        self.hard_cut_um = jnp.asarray(hard_cut_um)
        self.big_penalty = jnp.asarray(big_penalty)

    def __call__(self, x, y):
        d = jnp.linalg.norm(x - y)
        base = (d / self.r0) ** self.p
        extra = self.alpha * jnp.expm1(jnp.maximum(d - self.r0, 0.0) / self.sigma)
        normal_cost = base + extra
        return jnp.where(d <= self.hard_cut_um, normal_cost, self.big_penalty + normal_cost)

    def tree_flatten(self):
        return (
            self.r0,
            self.sigma,
            self.alpha,
            self.p,
            self.hard_cut_um,
            self.big_penalty,
        ), None

    @classmethod
    def tree_unflatten(cls, aux, children):
        r0, sigma, alpha, p, hard_cut_um, big_penalty = children
        return cls(r0, sigma, alpha, p, hard_cut_um, big_penalty)


def get_b_full(adata_soft: sc.AnnData, gene: str) -> np.ndarray:
    if gene not in adata_soft.var_names:
        raise KeyError(f"Gene {gene} not in OT1 soft h5ad var_names.")
    gidx = int(np.where(adata_soft.var_names == gene)[0][0])
    xg = adata_soft.X[:, gidx]
    if hasattr(xg, "toarray"):
        xg = xg.toarray().ravel()
    else:
        xg = np.asarray(xg).ravel()
    xg = np.maximum(xg.astype(np.float64), 0.0) + EPS_SAFE
    s = float(xg.sum())
    if s <= 0:
        return np.full((adata_soft.n_obs,), 1.0 / adata_soft.n_obs, dtype=np.float32)
    return (xg / s).astype(np.float32)


def load_windows(win_csv: str) -> pd.DataFrame:
    w = pd.read_csv(win_csv)
    required = {"window_id","x0","y0","x1","y1","xp0","yp0","xp1","yp1"}
    missing = required.difference(set(w.columns))
    if missing:
        raise KeyError(f"windows.csv missing columns: {sorted(list(missing))}")
    return w


def filter_bbox_xy(df: pd.DataFrame, x0, y0, x1, y1, xcol="x", ycol="y") -> pd.DataFrame:
    return df.loc[
        (df[xcol] >= x0) & (df[xcol] < x1) &
        (df[ycol] >= y0) & (df[ycol] < y1)
    ]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run_dir", required=True, help="Folder containing windows.csv, transcripts_min.parquet, cells_min.parquet")
    ap.add_argument("--ot1_soft_h5ad", required=True)
    ap.add_argument("--window_id_start", type=int, required=True)
    ap.add_argument("--window_id_end", type=int, required=True)

    # OT params
    ap.add_argument("--tau_a", type=float, default=0.8)
    ap.add_argument("--tau_b", type=float, default=0.9)
    ap.add_argument("--epsilon", type=float, default=0.05)
    ap.add_argument("--max_iters", type=int, default=2000)
    ap.add_argument("--thresh", type=float, default=1e-3)

    ap.add_argument("--r0", type=float, default=15.0)
    ap.add_argument("--p_in", type=float, default=2.0)
    ap.add_argument("--sigma", type=float, default=5.0)
    ap.add_argument("--alpha", type=float, default=10.0)

    ap.add_argument("--hard_cut_um", type=float, default=12.0)
    ap.add_argument("--big_penalty", type=float, default=1e6)
    ap.add_argument("--max_molecules_per_gene_window", type=int, default=None,
                    help="Debug only. Keep None to use all molecules in each window.")
    ap.add_argument("--genes_file", default=None,
                    help="Optional text file with one gene per line. If omitted, use OT1 var_names intersect window molecules.")
    args = ap.parse_args()

    run_dir = args.run_dir
    win_csv = os.path.join(run_dir, "windows.csv")
    tx_parq = os.path.join(run_dir, "transcripts_min.parquet")
    cell_parq = os.path.join(run_dir, "cells_min.parquet")

    out_root = os.path.join(run_dir, "worker_out")
    os.makedirs(out_root, exist_ok=True)

    windows = load_windows(win_csv)
    tx = pd.read_parquet(tx_parq)
    cells = pd.read_parquet(cell_parq)

    # Load OT1 soft (for b)
    ad_soft = sc.read_h5ad(args.ot1_soft_h5ad)
    ad_soft.obs_names = ad_soft.obs_names.astype(str)

    # Align cells in OT1 soft with cells_min
    cells = cells.copy()
    cells["cell_id"] = cells["cell_id"].astype(str)
    cell_xy_all_df = cells.set_index("cell_id")[["x","y"]]

    keep = ad_soft.obs_names.intersection(cell_xy_all_df.index)
    ad_soft = ad_soft[keep].copy()

    cell_xy_all = cell_xy_all_df.loc[ad_soft.obs_names].to_numpy(dtype=np.float32)
    cell_ids_all = ad_soft.obs_names.to_numpy()
    cell_tree = cKDTree(cell_xy_all)

    # genes constraint
    if args.genes_file is not None:
        with open(args.genes_file, "r") as f:
            genes_allow = [ln.strip() for ln in f if ln.strip()]
        genes_allow = set(genes_allow)
    else:
        genes_allow = None

    b_cache = {}
    summary = []

    wid0, wid1 = args.window_id_start, args.window_id_end
    for wid in range(wid0, wid1 + 1):
        wrow = windows.loc[windows["window_id"] == wid]
        if len(wrow) == 0:
            continue
        wrow = wrow.iloc[0]
        x0,y0,x1,y1 = float(wrow.x0), float(wrow.y0), float(wrow.x1), float(wrow.y1)
        xp0,yp0,xp1,yp1 = float(wrow.xp0), float(wrow.yp0), float(wrow.xp1), float(wrow.yp1)

        tx_w = filter_bbox_xy(tx, x0,y0,x1,y1, xcol="x", ycol="y")
        if tx_w.empty:
            continue

        genes_here = tx_w["gene"].unique().tolist()
        genes_here = [g for g in genes_here if g in set(ad_soft.var_names)]
        if genes_allow is not None:
            genes_here = [g for g in genes_here if g in genes_allow]
        if len(genes_here) == 0:
            continue

        wdir = os.path.join(out_root, f"window_{wid:06d}")
        os.makedirs(wdir, exist_ok=True)

        assign_dfs = []
        for gene in genes_here:
            sub = tx_w.loc[tx_w["gene"] == gene, ["mol_id", "x", "y"]].copy()
            if sub.empty:
                continue

            mol_ids = sub["mol_id"].to_numpy(dtype=np.int64)
            mol_xy = sub[["x","y"]].to_numpy(dtype=np.float32)
            M = mol_xy.shape[0]
            if M < 2:
                continue

            if args.max_molecules_per_gene_window is not None and M > args.max_molecules_per_gene_window:
                sub = sub.sort_values("mol_id").iloc[:int(args.max_molecules_per_gene_window)]
                mol_ids = sub["mol_id"].to_numpy(dtype=np.int64)
                mol_xy = sub[["x","y"]].to_numpy(dtype=np.float32)
                M = mol_xy.shape[0]

            neigh_lists = cell_tree.query_ball_point(mol_xy, r=float(args.hard_cut_um))
            flat = [np.asarray(lst, dtype=np.int64) for lst in neigh_lists if len(lst) > 0]
            if len(flat) == 0:
                continue
            candidate_idx = np.unique(np.concatenate(flat))
            if candidate_idx.size < 2:
                continue

            cell_xy = cell_xy_all[candidate_idx]
            cell_ids = cell_ids_all[candidate_idx]
            N = cell_xy.shape[0]

            a = np.full((M,), 1.0 / float(M), dtype=np.float32)

            if gene not in b_cache:
                b_cache[gene] = get_b_full(ad_soft, gene)  # sum=1 over all cells
            b_full = b_cache[gene]
            b = b_full[candidate_idx]
            b = (b.astype(np.float64) + EPS_SAFE)
            bs = float(b.sum())
            if bs <= 0:
                continue
            b = (b / bs).astype(np.float32)

            cost_fn = HardCutHingeExpDistanceCost(
                args.r0,
                args.sigma,
                args.alpha,
                args.p_in,
                args.hard_cut_um,
                args.big_penalty,
            )
            geom = pointcloud.PointCloud(
                x=jnp.asarray(mol_xy),
                y=jnp.asarray(cell_xy),
                cost_fn=cost_fn,
                epsilon=float(args.epsilon),
            )
            prob = linear_problem.LinearProblem(
                geom,
                a=jnp.asarray(a),
                b=jnp.asarray(b),
                tau_a=float(args.tau_a),
                tau_b=float(args.tau_b),
            )
            solver = sinkhorn.Sinkhorn(threshold=float(args.thresh), max_iterations=int(args.max_iters))
            out = solver(prob)
            conv = sinkhorn_diagnostics(out, args.max_iters, args.thresh)

            P = np.asarray(out.matrix, dtype=np.float32)
            row_sum = P.sum(axis=1, keepdims=True)
            row_sum[row_sum == 0] = 1.0
            P_row = P / row_sum
            best = P_row.argmax(axis=1)
            conf = P_row[np.arange(M), best]

            assigned = cell_ids[best].astype(str)

            assign_dfs.append(pd.DataFrame({
                "window_id": wid,
                "gene": gene,
                "mol_id": mol_ids,
                "assigned_cell": assigned,
                "assign_conf": conf.astype(np.float32),
            }))

            summary.append({
                "window_id": wid,
                "gene": gene,
                "M": int(M),
                "N": int(N),
                "hard_cut_um": float(args.hard_cut_um),
                "mean_conf": float(np.mean(conf)),
                "median_conf": float(np.median(conf)),
                "P_sum": float(P.sum()),
                **conv,
            })

        if len(assign_dfs) == 0:
            continue

        df_assign = pd.concat(assign_dfs, ignore_index=True)
        out_path = os.path.join(wdir, "assignments.parquet")
        df_assign.to_parquet(out_path, index=False)

        meta = {
            "window_id": wid,
            "bbox": {"x0": x0, "y0": y0, "x1": x1, "y1": y1},
            "pad_bbox": {"xp0": xp0, "yp0": yp0, "xp1": xp1, "yp1": yp1},
            "n_molecules": int(len(tx_w)),
            "candidate_rule": "per_gene_union_cells_within_hard_cut_um_of_molecules",
            "hard_cut_um": float(args.hard_cut_um),
            "jax_version": jax.__version__,
        }
        with open(os.path.join(wdir, "window_meta.json"), "w") as f:
            json.dump(meta, f, indent=2)

    if len(summary) > 0:
        df = pd.DataFrame(summary)
        df.to_csv(os.path.join(out_root, f"summary_{wid0:06d}_{wid1:06d}.csv"), index=False)

    print("DONE windows:", wid0, "to", wid1)


if __name__ == "__main__":
    main()

#!/bin/bash
set -euo pipefail

RUN_DIR=${1:?Usage: bash submit_ot2_hardcount_molneigh_windows.sh <RUN_DIR> <OT1_SOFT_H5AD> [MAX_CONCURRENT] [DEPENDENCY_JOBID]}
OT1_SOFT_H5AD=${2:?Usage: bash submit_ot2_hardcount_molneigh_windows.sh <RUN_DIR> <OT1_SOFT_H5AD> [MAX_CONCURRENT] [DEPENDENCY_JOBID]}
MAX_CONCURRENT=${3:-80}
DEPENDENCY_JOBID=${4:-}

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SBATCH_FILE="${SCRIPT_DIR}/run_ot2_hardcount_molneigh_windows.sbatch"
WIN_CSV="${RUN_DIR}/windows.csv"

if [[ ! -f "${WIN_CSV}" ]]; then
  echo "Missing ${WIN_CSV}. Run run_prepare_ot2_hardcount_molneigh_from_existing.sbatch first." >&2
  exit 1
fi

CHUNK=$(grep -E '^CHUNK_WINDOWS=' "${SBATCH_FILE}" | head -n1 | cut -d'=' -f2)
NWIN=$(( $(wc -l < "${WIN_CSV}") - 1 ))
NTASK=$(( (NWIN + CHUNK - 1) / CHUNK ))
ARRAY_END=$(( NTASK - 1 ))

echo "windows: ${NWIN}"
echo "chunk_windows: ${CHUNK}"
echo "array tasks: ${NTASK} (0-${ARRAY_END})"
echo "Submitting with throttle %${MAX_CONCURRENT}"

SBATCH_ARGS=(--parsable --array=0-"${ARRAY_END}"%"${MAX_CONCURRENT}")
if [[ -n "${DEPENDENCY_JOBID}" ]]; then
  SBATCH_ARGS+=(--dependency=afterok:${DEPENDENCY_JOBID})
fi

JOBID=$(sbatch "${SBATCH_ARGS[@]}" "${SBATCH_FILE}" "${RUN_DIR}" "${OT1_SOFT_H5AD}")
echo "${JOBID}"


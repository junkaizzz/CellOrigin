#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Summarize per-gene/window Sinkhorn convergence diagnostics written by
ot2_window_hardcount_molneigh_worker.py.
"""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


REQUIRED_COLUMNS = {
    "sinkhorn_converged",
    "sinkhorn_n_iters",
    "sinkhorn_reached_max_iters",
    "sinkhorn_last_error",
    "sinkhorn_min_error",
    "sinkhorn_threshold",
    "sinkhorn_max_iters",
}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run_dir", required=True)
    ap.add_argument("--out_prefix", default="ot2_sinkhorn_convergence")
    args = ap.parse_args()

    run_dir = Path(args.run_dir)
    worker_out = run_dir / "worker_out"
    files = sorted(worker_out.glob("summary_*.csv"))
    if not files:
        raise FileNotFoundError(f"No summary_*.csv files found in {worker_out}")

    frames = [pd.read_csv(p) for p in files]
    df = pd.concat(frames, ignore_index=True)
    missing = REQUIRED_COLUMNS.difference(df.columns)
    if missing:
        raise KeyError(
            "Convergence columns are missing. Rerun OT2 with the updated "
            f"molneigh worker first. Missing: {sorted(missing)}"
        )

    conv = df["sinkhorn_converged"].astype(bool)
    reached = df["sinkhorn_reached_max_iters"].astype(bool)
    n_iters = pd.to_numeric(df["sinkhorn_n_iters"], errors="coerce")
    last_error = pd.to_numeric(df["sinkhorn_last_error"], errors="coerce")

    summary = {
        "run_dir": str(run_dir),
        "n_summary_files": int(len(files)),
        "n_gene_window_problems": int(len(df)),
        "n_converged": int(conv.sum()),
        "converged_rate": float(conv.mean()),
        "n_not_converged": int((~conv).sum()),
        "not_converged_rate": float((~conv).mean()),
        "n_reached_max_iters": int(reached.sum()),
        "reached_max_iters_rate": float(reached.mean()),
        "sinkhorn_n_iters_min": float(n_iters.min()),
        "sinkhorn_n_iters_p01": float(n_iters.quantile(0.01)),
        "sinkhorn_n_iters_median": float(n_iters.median()),
        "sinkhorn_n_iters_mean": float(n_iters.mean()),
        "sinkhorn_n_iters_p95": float(n_iters.quantile(0.95)),
        "sinkhorn_n_iters_p99": float(n_iters.quantile(0.99)),
        "sinkhorn_n_iters_max": float(n_iters.max()),
        "sinkhorn_last_error_median": float(last_error.median()),
        "sinkhorn_last_error_p95": float(last_error.quantile(0.95)),
        "sinkhorn_last_error_max": float(last_error.max()),
    }

    out_json = run_dir / f"{args.out_prefix}_summary.json"
    out_dist = run_dir / f"{args.out_prefix}_n_iters_distribution.csv"
    out_bad = run_dir / f"{args.out_prefix}_not_converged.csv"

    out_json.write_text(json.dumps(summary, indent=2))
    (
        df.groupby(["sinkhorn_n_iters", "sinkhorn_converged"], dropna=False)
        .size()
        .reset_index(name="n_gene_window_problems")
        .sort_values(["sinkhorn_n_iters", "sinkhorn_converged"])
        .to_csv(out_dist, index=False)
    )
    df.loc[~conv].to_csv(out_bad, index=False)

    print(json.dumps(summary, indent=2))
    print("Saved:", out_json)
    print("Saved:", out_dist)
    print("Saved:", out_bad)


if __name__ == "__main__":
    main()

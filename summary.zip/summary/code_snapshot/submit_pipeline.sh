#!/bin/bash
set -euo pipefail

PIPE_DIR=/scratch/beul/jzhang79/projects/Moscot/code/OT12_all_exper
RUN_TAG=allcells_pcaexpr_lowrank20_a0p9_eps0_pca50
RUN_DIR=${PIPE_DIR}/results/ot2/hardcount_allcells_from_${RUN_TAG}
OT1_SOFT_H5AD=${PIPE_DIR}/results/ot1/${RUN_TAG}/spatial_patch_soft_barycentric_fgw_labelstruct_unweighted_typebalancedmarginal_unbalancedblend.h5ad
MAX_CONCURRENT=${1:-80}
JOB_RECORD=${PIPE_DIR}/results/job_ids_latest.txt
LOCK_FILE=${PIPE_DIR}/results/pipeline_submitted.lock

mkdir -p ${PIPE_DIR}/logs ${PIPE_DIR}/results

if [[ -f ${LOCK_FILE} && "${OT12_ALL_FORCE_RESUBMIT:-0}" != "1" && -s ${JOB_RECORD} ]]; then
  echo "Refusing to submit: ${LOCK_FILE} already exists." >&2
  echo "This prevents duplicate jobs writing the same all-cells outputs." >&2
  echo "If you intentionally want to resubmit, run:" >&2
  echo "  OT12_ALL_FORCE_RESUBMIT=1 bash OT12_all_exper/submit_pipeline.sh ${MAX_CONCURRENT}" >&2
  exit 2
fi

{
  echo "submitted_at=$(date -Is)"
  echo "run_tag=${RUN_TAG}"
  echo "run_dir=${RUN_DIR}"
  echo "max_concurrent=${MAX_CONCURRENT}"
} > ${LOCK_FILE}

: > ${JOB_RECORD}

OT1_JOBID=$(sbatch --parsable ${PIPE_DIR}/ot1/run_ot1_allcells_lowrank20_eps0_a0p9.sbatch)
echo "OT1_JOBID=${OT1_JOBID}" | tee -a ${JOB_RECORD}

UMAP_OT1_JOBID=$(sbatch --parsable --dependency=afterok:${OT1_JOBID} \
  ${PIPE_DIR}/eval/run_umap_ot1_allcells.sbatch)
echo "UMAP_OT1_JOBID=${UMAP_OT1_JOBID}" | tee -a ${JOB_RECORD}

PREP_JOBID=$(sbatch --parsable --dependency=afterok:${OT1_JOBID} \
  ${PIPE_DIR}/ot2/run_prepare_ot2_hardcount_allcells.sbatch \
  ${RUN_DIR} ${OT1_SOFT_H5AD})
echo "OT2_PREP_JOBID=${PREP_JOBID}" | tee -a ${JOB_RECORD}

SUBMIT_OT2_JOBID=$(sbatch --parsable --dependency=afterok:${PREP_JOBID} \
  ${PIPE_DIR}/ot2/run_submit_ot2_hardcount_and_downstream.sbatch \
  ${MAX_CONCURRENT})
echo "OT2_SUBMIT_WRAPPER_JOBID=${SUBMIT_OT2_JOBID}" | tee -a ${JOB_RECORD}

cat <<EOF
Submitted all-cells OT1 -> OT2 hard-count pipeline.

Job IDs are recorded in:
  ${JOB_RECORD}

The OT2 array/merge/UMAP job IDs will be appended after the submit wrapper starts.
EOF
